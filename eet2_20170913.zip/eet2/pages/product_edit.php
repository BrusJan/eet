<?php
	$section = 'product_edit';
	$action = 'create'; // or delete or edit
    require_once '../core/init.php';
	
	require_once header;
	
	require_once navigation;
?>
<div id="page-wrapper">
	<div class="row">
		<div class="col-md-4">
				
			    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST" role="form">

					<legend><h2 class="text-center"><?php if ($action == 'create') echo 'Vytvořit produkt'; else if ($action == 'edit') echo 'Upravit produkt'; ?></h2></legend>

					<div class="form-group">

						<label for="name">Název produktu</label>

						<div class="input-group">

							<input type="text" class="form-control" id="name" name="name" placeholder="" value="<?php if(isset($name)){echo $name;}?>" required="required" />

						</div>

					</div>
					
					<div class="form-group">

						<label for="type">Typ produktu</label>

						<div class="input-group">

							<select id="type" name="type" class="form-control">
								<option value="1" selected>Normal</option>
								<option value="2">Druhý typ</option>
								<option value="3">Třetí typ</option>
								<option value="4">Poslední typ</option>
							</select>

						</div>

					</div>

					<div class="form-group">

						<label for="description">Popis</label>

						<div class="input-group">

							<textarea name="description" rows="5" cols="50" placeholder="Popis produktu"></textarea> 

						</div>

					</div>

					<center><button type="submit" class="btn btn-info">Vytvořit</button></center>

				</form>

			</div>
	</div>
</div>
<?php
	require_once footer;
?>