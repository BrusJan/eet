<?php

	$section = 'login';
    require_once '../core/init.php';
echo 0;
	if (isset($_POST['username'])) 
	{
		echo 1;
		$username = Input::cleanData($_POST["username"]);
		$password = Input::cleanData($_POST["password"]);
		echo 2;
		if (Validate::check($username, $password) === true) 
		{	
	echo 3;
			$x = new User;
			if ($x->login($username, $password))
			{
				echo 'na dashboardu';
				Redirect::to(dashboard);
			} else echo 'login fail asi';
			
		}
	} else echo 'neni post';
echo 4;
	require_once header;
	
?>
<div id="page-wrapper">
	<div class="row" style="margin-top: 125px;">

			<div class="col-md-4"></div>

			<div class="col-md-4">
				
			    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST" role="form">

					<legend><h2 class="text-center">Přihlášení</h2></legend>

					<div class="form-group">

						<label for="username">Email</label>

						<div class="input-group">

							<span class="input-group-addon"><i class="fa fa-user"></i></span>

							<input type="text" class="form-control" id="username" name="username" placeholder="vas.email@seznam.cz" value="<?php if(isset($username)){echo $username;}?>" required="required" />

						</div>

					</div>

					<div class="form-group">

						<label for="password">Heslo</label>

						<div class="input-group">

							<span class="input-group-addon"><i class="fa fa-lock"></i></span>

							<input type="password" class="form-control" id="password" name="password" placeholder="Vaše heslo" required="required" />

						</div>

					</div>

					<center><button type="submit" class="btn btn-info">Přihlásit</button></center>

				</form>

			</div>

			<div class="col-md-4"></div>

</div>
</div>
<?php
	require_once footer;
?>
