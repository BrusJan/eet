<?php
	$section = 'dashboard';
    require_once '../core/init.php';
	
	require_once header;
	
	require_once navigation;
?>
<div id="page-wrapper">
	<h1>No a tady si dám vobsach</h1>
</div>
<?php
	require_once footer;
?>