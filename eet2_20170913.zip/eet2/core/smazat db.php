<?php
$server   = "localhost";
$database = "d90246_eet";
$username = "root";
$password = "admin1";

$mysqli = new mysqli($server, $username, $password, $database);
if (!$mysqli){
    die("Database Connection Failed" . mysql_error());
}
?>