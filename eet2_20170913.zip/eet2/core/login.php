<?php
	if (isset($_POST['submit'])) 
	{
		echo 'submituju';
		$username = Input::cleanData($_POST["username"]);
		$password = Input::cleanData($_POST["password"]);
		echo 'submituju2';
		if (Validate::check($username, $password) === true) 
		{	
	echo 'check login';
			$x = new User;
			if ($x->login($username, $password))
			{
				echo 'na dashboardu';
				Redirect::to(dashboard);
			}
			
		} else echo 'not validated';
	}
?>