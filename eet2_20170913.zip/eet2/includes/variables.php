<?php
	$baseUrl = baseUrl;
?>