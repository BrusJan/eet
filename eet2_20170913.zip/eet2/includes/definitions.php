<?php
	/**
	* @author Kidhoma Norman
	*/
	define('header', rootPath . '/includes/header.php');
	define('footer', rootPath . '/includes/footer.php');
	// Define Side NavBar 
	define('navigation', rootPath . '/includes/navigation.php');
	/**
	*  Define Views of system
	*/
	//Define home view of system
	define('dashboard', rootPath . '/pages/dashboard.php');
	//Define login view of system
	define('productList', rootPath . '/pages/product_list.php');
	//Define classmates view of system
	define('productEdit', rootPath . '/pages/product_edit.php');
	//Define downloads view of system
	define('settings', rootPath . '/pages/settings.php');
	define('login', rootPath . '/pages/login.php');
	define('logout', rootPath . '/pages/logout.php');
	/**
	*  End Define Views of system
	*/
?>