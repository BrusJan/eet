using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IDC.Connector.Infrastructure.Attributes;

namespace IDC.Connector.Infrastructure.Remote
{
	[RemoteName("com.idc_cema.ferda.api.IIFailedResponse")]
	public interface IIFailedResponse
	{
		[JsonProperty("failureMessage")]
		String FailureMessage { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.api.IIIncompleteResponse")]
	public interface IIIncompleteResponse
	{
		[JsonProperty("message")]
		String Message { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.api.IIRequest")]
	public interface IIRequest
	{
		[JsonProperty("id")]
		String Id { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.api.IIResponse")]
	public interface IIResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.api.IISucceededResponse")]
	public interface IISucceededResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.common.service.IAsyncRequest")]
	public interface IAsyncRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.api.remote.ClientSwitch")]
	public enum ClientSwitch
	{
		TRANSACTION_PER_REQUEST
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteAbsoluteConsecutiveCheck")]
	public class RemoteAbsoluteConsecutiveCheck : RemoteConsecutiveCheck
	{
		[JsonProperty("descriptorFilter")]
		public RemoteCriteriaFilter DescriptorFilter { get; set; }
		[JsonProperty("searchFilter")]
		public RemoteCriteriaFilter SearchFilter { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.account.remote.RemoteAccount")]
	public class RemoteAccount
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("country")]
		public String Country { get; set; }
		[JsonProperty("source")]
		public RemoteSource Source { get; set; }
		[JsonProperty("status")]
		public RemoteStatus Status { get; set; }
		[JsonProperty("address1")]
		public String Address1 { get; set; }
		[JsonProperty("address2")]
		public String Address2 { get; set; }
		[JsonProperty("address3")]
		public String Address3 { get; set; }
		[JsonProperty("address4")]
		public String Address4 { get; set; }
		[JsonProperty("address5")]
		public String Address5 { get; set; }
		[JsonProperty("city")]
		public String City { get; set; }
		[JsonProperty("zipcode")]
		public String Zipcode { get; set; }
		[JsonProperty("phone")]
		public String Phone { get; set; }
		[JsonProperty("extendedDays")]
		public int? ExtendedDays { get; set; }
		[JsonProperty("accountType")]
		public String AccountType { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.account.remote.RemoteAccountGroup")]
	public class RemoteAccountGroup
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("status")]
		public String Status { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteAddAttributeDef")]
	public class RemoteAddAttributeDef
	{
		[JsonProperty("attribute")]
		public RemoteAttribute Attribute { get; set; }
		[JsonProperty("levelNumber")]
		public int LevelNumber { get; set; }
		[JsonProperty("valueToFill")]
		public Object ValueToFill { get; set; }
		[JsonProperty("dimensionMapAttribute")]
		public RemoteDimensionMapAttribute DimensionMapAttribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteAddAttributesToDimensionMapRequest")]
	public class RemoteAddAttributesToDimensionMapRequest : RemoteRequest
	{
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
		[JsonProperty("addAttributeDefs")]
		public HashSet<RemoteAddAttributeDef> AddAttributeDefs { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteAddColumnValueTransformation")]
	public class RemoteAddColumnValueTransformation : RemoteTransformation
	{
		[JsonProperty("columnValue")]
		public RemoteMap ColumnValue { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteAddDimensionDef")]
	public abstract class RemoteAddDimensionDef
	{
		[JsonProperty("levelNumber")]
		public int LevelNumber { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteAddDimensionExistingDef")]
	public class RemoteAddDimensionExistingDef : RemoteAddDimensionDef
	{
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
		[JsonProperty("nodeToFill")]
		public long? NodeToFill { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteAddDimensionNewDef")]
	public class RemoteAddDimensionNewDef : RemoteAddDimensionDef
	{
		[JsonProperty("caption")]
		public String Caption { get; set; }
		[JsonProperty("valuesToFill")]
		public RemoteMap ValuesToFill { get; set; }
		[JsonProperty("addAttributeDefs")]
		public HashSet<RemoteAddAttributeDef> AddAttributeDefs { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteAddDimensionToDimensionMapRequest")]
	public class RemoteAddDimensionToDimensionMapRequest : RemoteRequest
	{
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
		[JsonProperty("addDimensionDefs")]
		public HashSet<RemoteAddDimensionDef> AddDimensionDefs { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteAddMissingSplitToDefaultTrans")]
	public class RemoteAddMissingSplitToDefaultTrans : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteAddShareDerivedAttributeRequest")]
	public class RemoteAddShareDerivedAttributeRequest : RemoteGenerateAttributeRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteAddShIdToDbStructureTrans")]
	public class RemoteAddShIdToDbStructureTrans : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteAddShipmentAttributeRequest")]
	public class RemoteAddShipmentAttributeRequest : RemoteRequest
	{
		[JsonProperty("defaultValue")]
		public Object DefaultValue { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.RemoteAggregatePivotCell")]
	public class RemoteAggregatePivotCell : RemoteBasePivotCell
	{
		[JsonProperty("aggregatedCells")]
		public HashSet<RemoteBasePivotCell> AggregatedCells { get; set; }
		[JsonProperty("childrenColumn")]
		public HashSet<RemoteAggregatePivotCell> ChildrenColumn { get; set; }
		[JsonProperty("operations")]
		public HashSet<RemotePivotOperation> Operations { get; set; }
		[JsonProperty("childrenRow")]
		public HashSet<RemoteAggregatePivotCell> ChildrenRow { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteAggregateRequest")]
	public class RemoteAggregateRequest : RemoteRequest
	{
		[JsonProperty("id")]
		public String Id { get; set; }
		[JsonProperty("requests")]
		public RemoteList Requests { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.response.RemoteAggregateResponse")]
	public class RemoteAggregateResponse : RemoteResponse
	{
		[JsonProperty("responses")]
		public RemoteList Responses { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteAlignSplitDimensionEntry")]
	public class RemoteAlignSplitDimensionEntry
	{
		[JsonProperty("fromNodes")]
		public HashSet<long?> FromNodes { get; set; }
		[JsonProperty("toNodes")]
		public HashSet<long?> ToNodes { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteAlignSplitResult")]
	public class RemoteAlignSplitResult : RemoteResponse
	{
		[JsonProperty("total")]
		public int Total { get; set; }
		[JsonProperty("skipped")]
		public int Skipped { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteAlignSplits")]
	public class RemoteAlignSplits : RemoteRequest
	{
		[JsonProperty("descriptor")]
		public RemoteMassDescriptor Descriptor { get; set; }
		[JsonProperty("splitsToAlign")]
		public HashSet<RemoteAlignSplitDimensionEntry> SplitsToAlign { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("figures")]
		public HashSet<String> Figures { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.rule.remote.RemoteAllowedDimension")]
	public class RemoteAllowedDimension : RemoteDimensionSpecification
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteAllowedFilterAttribute")]
	public class RemoteAllowedFilterAttribute
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.rule.remote.RemoteAllowedNode")]
	public class RemoteAllowedNode
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("node")]
		public long? Node { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("rule")]
		public long? Rule { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteAnalystRole")]
	public class RemoteAnalystRole
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("role")]
		public String Role { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteAppendShipmentIdTransformation")]
	public class RemoteAppendShipmentIdTransformation : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteApplicationServer")]
	public class RemoteApplicationServer : RemoteServer
	{
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteApplyImplicitModel")]
	public class RemoteApplyImplicitModel : RemoteRequest
	{
		[JsonProperty("sourceFigures")]
		public HashSet<String> SourceFigures { get; set; }
		[JsonProperty("sourceSplitId")]
		public String SourceSplitId { get; set; }
		[JsonProperty("targetData")]
		public RemoteQueryFilterGroup TargetData { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("databaseName")]
		public String DatabaseName { get; set; }
		[JsonProperty("sourceData")]
		public RemoteQueryFilterGroup SourceData { get; set; }
		[JsonProperty("sourceAttributes")]
		public HashSet<String> SourceAttributes { get; set; }
		[JsonProperty("destinationData")]
		public RemoteQueryFilterGroup DestinationData { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteAttribute")]
	public abstract class RemoteAttribute
	{
		[JsonProperty("id")]
		public String Id { get; set; }
		[JsonProperty("type")]
		public int? Type { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("caption")]
		public String Caption { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.RemoteAttributeAxisItem")]
	public class RemoteAttributeAxisItem : RemotePivotAxisItem
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteAttributeColumn")]
	public class RemoteAttributeColumn : RemoteColumn
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteAttributeDeliveryColumn")]
	public class RemoteAttributeDeliveryColumn : RemoteDeliveryColumn
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteAttributeFilterItem")]
	public class RemoteAttributeFilterItem : RemoteFilterItem
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.profiling.RemoteAttributeGroup")]
	public class RemoteAttributeGroup
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("headers")]
		public HashSet<RemoteAttributeGroupHeader> Headers { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.profiling.RemoteAttributeGroupHeader")]
	public class RemoteAttributeGroupHeader
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("order")]
		public int Order { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("numericOperator")]
		public String NumericOperator { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.configuration.RemoteAttributeGrouping")]
	public class RemoteAttributeGrouping
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("rowAttributes")]
		public HashSet<RemoteOrderedAttribute> RowAttributes { get; set; }
		[JsonProperty("attributeGroupingValues")]
		public HashSet<RemoteAttributeGroupingValue> AttributeGroupingValues { get; set; }
		[JsonProperty("columnAttributes")]
		public HashSet<RemoteOrderedAttribute> ColumnAttributes { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteAttributeGroupingValue")]
	public class RemoteAttributeGroupingValue
	{
		[JsonProperty("attributeGroupingValueId")]
		public long? AttributeGroupingValueId { get; set; }
		[JsonProperty("attributeGroupingValue")]
		public String AttributeGroupingValue { get; set; }
		[JsonProperty("attributeQueryFilterGroup")]
		public RemoteQueryFilterGroup AttributeQueryFilterGroup { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteAttributeJobParameter")]
	public class RemoteAttributeJobParameter : RemoteJobParameter
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteAttributeKey")]
	public class RemoteAttributeKey : RemoteCriteriaKey
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.dto.RemoteAttributeOutputItem")]
	public class RemoteAttributeOutputItem : RemoteOutputItem
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteAttributeRenameMapping")]
	public class RemoteAttributeRenameMapping : RemoteITransRenameMapping
	{
		[JsonProperty("target")]
		public String Target { get; set; }
		[JsonProperty("source")]
		public String Source { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteAttributeSort")]
	public class RemoteAttributeSort
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("valuesOrder")]
		public HashSet<RemoteAttributeValueOrder> ValuesOrder { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteAttributeValueOrder")]
	public class RemoteAttributeValueOrder
	{
		[JsonProperty("value")]
		public String Value { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
		[JsonProperty("attributeSort")]
		public long? AttributeSort { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.cron.remote.RemoteBackupRestoreRequest")]
	public class RemoteBackupRestoreRequest : RemoteRequest
	{
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.RemoteBasePivotCell")]
	public class RemoteBasePivotCell
	{
		[JsonProperty("descriptor")]
		public RemoteDescriptor Descriptor { get; set; }
		[JsonProperty("figures")]
		public RemoteFigurePack Figures { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteBookmark")]
	public class RemoteBookmark : RemoteUserDefinition
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteBookmarkNavigatorNode")]
	public class RemoteBookmarkNavigatorNode : RemoteUserDefinitionNavigatorNode
	{
		[JsonProperty("bookmark")]
		public RemoteBookmark Bookmark { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientcache.remote.RemoteBuildCacheRequest")]
	public class RemoteBuildCacheRequest : RemoteRequest
	{
		[JsonProperty("version")]
		public long Version { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteClassicalCheck")]
	public class RemoteClassicalCheck : RemoteConstraint
	{
		[JsonProperty("attributes")]
		public HashSet<String> Attributes { get; set; }
		[JsonProperty("procedureName")]
		public String ProcedureName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteCleanAttributeStoredProcedureRequest")]
	public class RemoteCleanAttributeStoredProcedureRequest : RemoteRequest
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.auth.remote.RemoteCleanAuthKeyRequest")]
	public class RemoteCleanAuthKeyRequest : RemoteRequest
	{
		[JsonProperty("username")]
		public String Username { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteCleanDataModelRequest")]
	public class RemoteCleanDataModelRequest : RemoteRequest
	{
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("dataModel")]
		public long? DataModel { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.procedure.RemoteCleanTransStoredProcedureRequest")]
	public class RemoteCleanTransStoredProcedureRequest : RemoteTransStoredProcedureRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteCleanUpRequest")]
	public abstract class RemoteCleanUpRequest : RemoteRequest
	{
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("targetDatabase")]
		public String TargetDatabase { get; set; }
		[JsonProperty("figureCriteria")]
		public HashSet<RemoteFigureCriteria> FigureCriteria { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteCleanUpResponse")]
	public class RemoteCleanUpResponse : RemoteResponse
	{
		[JsonProperty("shipments")]
		public HashSet<RemoteFigureRecord> Shipments { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteCleanUpTrans")]
	public class RemoteCleanUpTrans : RemoteTransformation
	{
		[JsonProperty("jobId")]
		public String JobId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.cache.remote.RemoteClearCache")]
	public class RemoteClearCache : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteClearShipmentRegister")]
	public class RemoteClearShipmentRegister : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.RemoteClient")]
	public class RemoteClient
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("shortName")]
		public String ShortName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteClientDeliveryClient")]
	public class RemoteClientDeliveryClient
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("clientId")]
		public long? ClientId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.profile.RemoteClientDeliveryClientProfile")]
	public class RemoteClientDeliveryClientProfile
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("queryFilterGroup")]
		public RemoteQueryFilterGroup QueryFilterGroup { get; set; }
		[JsonProperty("attributeGrouping")]
		public HashSet<RemoteAttributeGrouping> AttributeGrouping { get; set; }
		[JsonProperty("profileId")]
		public long? ProfileId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteClientDeliveryConfiguration")]
	public class RemoteClientDeliveryConfiguration
	{
		[JsonProperty("configurationId")]
		public long? ConfigurationId { get; set; }
		[JsonProperty("chl_tracker_org_prod_id")]
		public String Chl_tracker_org_prod_id { get; set; }
		[JsonProperty("timemapStartPeriodNodeId")]
		public long? TimemapStartPeriodNodeId { get; set; }
		[JsonProperty("client")]
		public RemoteClientDeliveryClient Client { get; set; }
		[JsonProperty("profile")]
		public RemoteClientDeliveryClientProfile Profile { get; set; }
		[JsonProperty("report")]
		public RemoteClientDeliveryReport Report { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteClientDeliveryDocument")]
	public class RemoteClientDeliveryDocument
	{
		[JsonProperty("items")]
		public HashSet<RemoteClientDeliveryDocumentItem> Items { get; set; }
		[JsonProperty("documentId")]
		public long? DocumentId { get; set; }
		[JsonProperty("documentName")]
		public String DocumentName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteClientDeliveryDocumentItem")]
	public class RemoteClientDeliveryDocumentItem
	{
		[JsonProperty("constant")]
		public String Constant { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
		[JsonProperty("currencyId")]
		public String CurrencyId { get; set; }
		[JsonProperty("itemId")]
		public long? ItemId { get; set; }
		[JsonProperty("targetColumn")]
		public String TargetColumn { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("denominator")]
		public String Denominator { get; set; }
		[JsonProperty("attributeGroupingValues")]
		public HashSet<RemoteAttributeGroupingValue> AttributeGroupingValues { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.welcomescreen.remote.RemoteClientDeliveryFolder")]
	public class RemoteClientDeliveryFolder : RemoteFolder
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteClientDeliveryPivotTableDefinitionItem")]
	public class RemoteClientDeliveryPivotTableDefinitionItem
	{
		[JsonProperty("definition")]
		public RemotePivotDefinition Definition { get; set; }
		[JsonProperty("fileName")]
		public String FileName { get; set; }
		[JsonProperty("placeholder")]
		public RemotePlaceholder Placeholder { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteClientDeliveryPivotTableRequest")]
	public class RemoteClientDeliveryPivotTableRequest : RemoteRequest
	{
		[JsonProperty("format")]
		public RemoteDeliveryFormat Format { get; set; }
		[JsonProperty("user")]
		public String User { get; set; }
		[JsonProperty("usedFigures")]
		public HashSet<RemoteFigure> UsedFigures { get; set; }
		[JsonProperty("outputFileName")]
		public String OutputFileName { get; set; }
		[JsonProperty("excelTemplateFile")]
		public RemoteDeliveryTemplateFile ExcelTemplateFile { get; set; }
		[JsonProperty("definitionItems")]
		public HashSet<RemoteClientDeliveryPivotTableDefinitionItem> DefinitionItems { get; set; }
		[JsonProperty("usedCurrencies")]
		public HashSet<RemoteCurrency> UsedCurrencies { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteClientDeliveryReport")]
	public class RemoteClientDeliveryReport
	{
		[JsonProperty("target")]
		public String Target { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("reportId")]
		public long? ReportId { get; set; }
		[JsonProperty("documents")]
		public HashSet<RemoteClientDeliveryDocument> Documents { get; set; }
		[JsonProperty("reportName")]
		public String ReportName { get; set; }
		[JsonProperty("mdbSingleFile")]
		public bool MdbSingleFile { get; set; }
		[JsonProperty("flow")]
		public String Flow { get; set; }
		[JsonProperty("exchangeRates")]
		public HashSet<long?> ExchangeRates { get; set; }
		[JsonProperty("queryFilterGroup")]
		public RemoteQueryFilterGroup QueryFilterGroup { get; set; }
		[JsonProperty("countrysOwnCurrencyFlag")]
		public bool CountrysOwnCurrencyFlag { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.profiling.RemoteClientProfile")]
	public class RemoteClientProfile
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("profileOwner")]
		public String ProfileOwner { get; set; }
		[JsonProperty("attributeGroups")]
		public List<RemoteAttributeGroup> AttributeGroups { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.profile.RemoteCloneClientDeliveryProfileRequest")]
	public class RemoteCloneClientDeliveryProfileRequest : RemoteRequest
	{
		[JsonProperty("profileId")]
		public long? ProfileId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteColumn")]
	public abstract class RemoteColumn
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteCombinationCheck")]
	public abstract class RemoteCombinationCheck : RemoteConstraint
	{
		[JsonProperty("specification")]
		public RemoteQueryFilterGroup Specification { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.comment.remote.RemoteComment")]
	public abstract class RemoteComment
	{
		[JsonProperty("descriptor")]
		public RemoteDimensionDescriptor Descriptor { get; set; }
		[JsonProperty("commentId")]
		public long? CommentId { get; set; }
		[JsonProperty("text")]
		public String Text { get; set; }
		[JsonProperty("username")]
		public String Username { get; set; }
		[JsonProperty("created")]
		public DateTime? Created { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteCommonDeliveryConfig")]
	public class RemoteCommonDeliveryConfig
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("exchangeRates")]
		public HashSet<long?> ExchangeRates { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.contact.remote.RemoteCompany")]
	public class RemoteCompany
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("type")]
		public String Type { get; set; }
		[JsonProperty("webUrl")]
		public String WebUrl { get; set; }
		[JsonProperty("companyOwner")]
		public String CompanyOwner { get; set; }
		[JsonProperty("note")]
		public String Note { get; set; }
		[JsonProperty("fiscalYearEnd")]
		public DateTime? FiscalYearEnd { get; set; }
		[JsonProperty("hqCountry")]
		public long? HqCountry { get; set; }
		[JsonProperty("vendor")]
		public long? Vendor { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteComparisonDescriptorParameter")]
	public class RemoteComparisonDescriptorParameter : RemoteComparisonParameter
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteComparisonCheck")]
	public abstract class RemoteComparisonCheck : RemoteCombinationCheck
	{
		[JsonProperty("figureDeltas")]
		public HashSet<RemoteFigureDelta> FigureDeltas { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteComparisonCheckOutput")]
	public class RemoteComparisonCheckOutput : RemoteCheckOutput
	{
		[JsonProperty("rows")]
		public HashSet<RemoteComparisonCheckRow> Rows { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteComparisonCheckParameter")]
	public class RemoteComparisonCheckParameter : RemoteComparisonParameter
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteComparisonCheckRow")]
	public class RemoteComparisonCheckRow : RemoteCheckRow
	{
		[JsonProperty("baseFigurePack")]
		public RemoteNewFigurePack BaseFigurePack { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteComparisonCheckTransformation")]
	public class RemoteComparisonCheckTransformation : RemoteTransformation
	{
		[JsonProperty("descriptor")]
		public HashSet<RemoteComparisonDescriptorParameter> Descriptor { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("renameMapping")]
		public HashSet<RemoteTransformationRenameMapping> RenameMapping { get; set; }
		[JsonProperty("sourceTechnology")]
		public String SourceTechnology { get; set; }
		[JsonProperty("checkParameters")]
		public HashSet<RemoteComparisonCheckParameter> CheckParameters { get; set; }
		[JsonProperty("primSpecFilterParam")]
		public HashSet<RemoteComparisonPrimSpecFilterParameter> PrimSpecFilterParam { get; set; }
		[JsonProperty("secondSpecFilterParam")]
		public HashSet<RemoteComparisonSecSpecFilterParameter> SecondSpecFilterParam { get; set; }
		[JsonProperty("secondarySnapshot")]
		public String SecondarySnapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteComparisonParameter")]
	public class RemoteComparisonParameter
	{
		[JsonProperty("key")]
		public String Key { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("values")]
		public HashSet<String> Values { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteComparisonPrimSpecFilterParameter")]
	public class RemoteComparisonPrimSpecFilterParameter : RemoteComparisonParameter
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteComparisonSecSpecFilterParameter")]
	public class RemoteComparisonSecSpecFilterParameter : RemoteComparisonParameter
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteCompleteFlushTask")]
	public class RemoteCompleteFlushTask : RemoteRequest
	{
		[JsonProperty("files")]
		public RemoteMap Files { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.RemoteCompleteJobTransRequest")]
	public class RemoteCompleteJobTransRequest : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteCompleteMoveTechnologySchemaRequest")]
	public class RemoteCompleteMoveTechnologySchemaRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("targetSnapshot")]
		public String TargetSnapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteCompletePivotFlushTask")]
	public class RemoteCompletePivotFlushTask : RemoteRequest
	{
		[JsonProperty("format")]
		public long? Format { get; set; }
		[JsonProperty("outputFileName")]
		public String OutputFileName { get; set; }
		[JsonProperty("excelTemplateFile")]
		public long? ExcelTemplateFile { get; set; }
		[JsonProperty("definitionItems")]
		public HashSet<RemoteClientDeliveryPivotTableDefinitionItem> DefinitionItems { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteCompleteQueryToolFlushTask")]
	public class RemoteCompleteQueryToolFlushTask : RemoteCompleteFlushTask
	{
		[JsonProperty("format")]
		public long? Format { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteCompositeFigureRecord")]
	public class RemoteCompositeFigureRecord : RemoteFigureRecord
	{
		[JsonProperty("primaryVersion")]
		public String PrimaryVersion { get; set; }
		[JsonProperty("secondaryVersion")]
		public String SecondaryVersion { get; set; }
		[JsonProperty("secondaryFigurePack")]
		public RemoteFigurePack SecondaryFigurePack { get; set; }
		[JsonProperty("secondaryDerivativePack")]
		public RemoteMultiFigureDerivativePack SecondaryDerivativePack { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteComputationNavigatorNode")]
	public class RemoteComputationNavigatorNode : RemoteNavigatorNode
	{
		[JsonProperty("computation")]
		public RemoteProcedureJob Computation { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.auth.remote.RemoteConfirmAuthKeyRequest")]
	public class RemoteConfirmAuthKeyRequest : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteConsecutiveCheck")]
	public abstract class RemoteConsecutiveCheck : RemoteComparisonCheck
	{
		[JsonProperty("numOfQuarters")]
		public int NumOfQuarters { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteConstantDeliveryColumn")]
	public class RemoteConstantDeliveryColumn : RemoteDeliveryColumn
	{
		[JsonProperty("value")]
		public String Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteConstraint")]
	public abstract class RemoteConstraint : RemoteCheck
	{
		[JsonProperty("output")]
		public HashSet<RemoteCheckOutputItem> Output { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.welcomescreen.remote.RemoteConsultingFolder")]
	public class RemoteConsultingFolder : RemoteFolder
	{
	}

	[RemoteName("com.idc_cema.ferda.contact.remote.RemoteContact")]
	public class RemoteContact
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("country")]
		public long? Country { get; set; }
		[JsonProperty("note")]
		public String Note { get; set; }
		[JsonProperty("firstName")]
		public String FirstName { get; set; }
		[JsonProperty("lastName")]
		public String LastName { get; set; }
		[JsonProperty("email")]
		public String Email { get; set; }
		[JsonProperty("title")]
		public String Title { get; set; }
		[JsonProperty("company")]
		public long? Company { get; set; }
		[JsonProperty("city")]
		public String City { get; set; }
		[JsonProperty("phone")]
		public String Phone { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.contract.RemoteContract")]
	public class RemoteContract
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("template")]
		public long? Template { get; set; }
		[JsonProperty("price")]
		public double Price { get; set; }
		[JsonProperty("startDate")]
		public DateTime? StartDate { get; set; }
		[JsonProperty("endDate")]
		public DateTime? EndDate { get; set; }
		[JsonProperty("member")]
		public String Member { get; set; }
		[JsonProperty("deliverables")]
		public HashSet<RemoteContractDeliverable> Deliverables { get; set; }
		[JsonProperty("client")]
		public long? Client { get; set; }
		[JsonProperty("regionType")]
		public String RegionType { get; set; }
		[JsonProperty("defaultProfile")]
		public RemoteClientProfile DefaultProfile { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.contract.RemoteContractDashboardItem")]
	public class RemoteContractDashboardItem
	{
		[JsonProperty("format")]
		public String Format { get; set; }
		[JsonProperty("contract")]
		public long? Contract { get; set; }
		[JsonProperty("deliverable")]
		public long? Deliverable { get; set; }
		[JsonProperty("clientName")]
		public String ClientName { get; set; }
		[JsonProperty("productName")]
		public String ProductName { get; set; }
		[JsonProperty("items")]
		public List<long?> Items { get; set; }
		[JsonProperty("regionType")]
		public String RegionType { get; set; }
		[JsonProperty("clientShortName")]
		public String ClientShortName { get; set; }
		[JsonProperty("productShortName")]
		public String ProductShortName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.contract.RemoteContractDeliverable")]
	public class RemoteContractDeliverable
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("schedule")]
		public HashSet<long?> Schedule { get; set; }
		[JsonProperty("groupId")]
		public long? GroupId { get; set; }
		[JsonProperty("endPeriod")]
		public long? EndPeriod { get; set; }
		[JsonProperty("profile")]
		public RemoteClientProfile Profile { get; set; }
		[JsonProperty("startPeriod")]
		public long? StartPeriod { get; set; }
		[JsonProperty("templateDeliverable")]
		public long? TemplateDeliverable { get; set; }
		[JsonProperty("deliveredItems")]
		public HashSet<long?> DeliveredItems { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.contract.RemoteContractTemplate")]
	public class RemoteContractTemplate
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("technologies")]
		public HashSet<String> Technologies { get; set; }
		[JsonProperty("deliverables")]
		public HashSet<RemoteContractTemplateDeliverable> Deliverables { get; set; }
		[JsonProperty("items")]
		public List<RemoteContractTemplateItem> Items { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.contract.RemoteContractTemplateDeliverable")]
	public class RemoteContractTemplateDeliverable
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("format")]
		public long? Format { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.contract.RemoteContractTemplateItem")]
	public class RemoteContractTemplateItem
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attributes")]
		public HashSet<String> Attributes { get; set; }
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("order")]
		public int Order { get; set; }
		[JsonProperty("label1")]
		public String Label1 { get; set; }
		[JsonProperty("label2")]
		public String Label2 { get; set; }
		[JsonProperty("label3")]
		public String Label3 { get; set; }
		[JsonProperty("color")]
		public String Color { get; set; }
		[JsonProperty("figures")]
		public HashSet<String> Figures { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteConvertedNodeFigureColumn")]
	public class RemoteConvertedNodeFigureColumn : RemoteFigureColumn
	{
		[JsonProperty("valueId")]
		public Object ValueId { get; set; }
		[JsonProperty("columnId")]
		public String ColumnId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteConvertToAggrFigureTransformation")]
	public class RemoteConvertToAggrFigureTransformation : RemoteTransformation
	{
		[JsonProperty("notAggregatableFigureList")]
		public List<String> NotAggregatableFigureList { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteCopySchemaRequest")]
	public class RemoteCopySchemaRequest : RemoteRequest
	{
		[JsonProperty("schemas")]
		public List<String> Schemas { get; set; }
		[JsonProperty("sourceSnapshot")]
		public String SourceSnapshot { get; set; }
		[JsonProperty("targetSnapshots")]
		public List<String> TargetSnapshots { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteCopyTechnologyProfileRequest")]
	public class RemoteCopyTechnologyProfileRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("groups")]
		public List<long?> Groups { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteCopyTechnologySchemaRequest")]
	public class RemoteCopyTechnologySchemaRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("targetSnapshot")]
		public String TargetSnapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteCountRequest")]
	public class RemoteCountRequest : RemoteRequest
	{
		[JsonProperty("clazz")]
		public String Clazz { get; set; }
		[JsonProperty("criteriaFilter")]
		public RemoteCriteriaFilter CriteriaFilter { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.response.RemoteCountResponse")]
	public class RemoteCountResponse : RemoteResponse
	{
		[JsonProperty("count")]
		public long? Count { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.comment.remote.RemoteCreateComment")]
	public abstract class RemoteCreateComment : RemoteRequest
	{
		[JsonProperty("descriptor")]
		public RemoteDimensionDescriptor Descriptor { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("commentId")]
		public long? CommentId { get; set; }
		[JsonProperty("text")]
		public String Text { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.comment.remote.RemoteCreateDataComment")]
	public class RemoteCreateDataComment : RemoteCreateComment
	{
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteCreateDataModelRequest")]
	public class RemoteCreateDataModelRequest : RemoteRequest
	{
		[JsonProperty("dataModel")]
		public long? DataModel { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.comment.remote.RemoteCreateGuidance")]
	public class RemoteCreateGuidance : RemoteCreateComment
	{
		[JsonProperty("type")]
		public String Type { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.schema.remote.RemoteCreateOrReplaceFormulaCheckConstraintsRequest")]
	public class RemoteCreateOrReplaceFormulaCheckConstraintsRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteCreateShipmentFlatTableTransformation")]
	public class RemoteCreateShipmentFlatTableTransformation : RemoteTransformation
	{
		[JsonProperty("attributes")]
		public HashSet<String> Attributes { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("filterGroup")]
		public RemoteQueryFilterGroup FilterGroup { get; set; }
		[JsonProperty("figures")]
		public HashSet<String> Figures { get; set; }
		[JsonProperty("sourceTechnology")]
		public String SourceTechnology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteCreateTableFromCsvTransformation")]
	public class RemoteCreateTableFromCsvTransformation : RemoteTransformation
	{
		[JsonProperty("file")]
		public long? File { get; set; }
		[JsonProperty("dataSeparator")]
		public char DataSeparator { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteria")]
	public abstract class RemoteCriteria
	{
		[JsonProperty("key")]
		public RemoteCriteriaKey Key { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteCriteriaAllowedDimension")]
	public class RemoteCriteriaAllowedDimension : RemoteCriteriaIn
	{
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaBetween")]
	public class RemoteCriteriaBetween : RemoteCriteria
	{
		[JsonProperty("value")]
		public RemoteList Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteCriteriaDerivedAttribute")]
	public class RemoteCriteriaDerivedAttribute : RemoteDerivedAttribute
	{
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaEquals")]
	public class RemoteCriteriaEquals : RemoteCriteria
	{
		[JsonProperty("value")]
		public Object Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaFilter")]
	public class RemoteCriteriaFilter
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("criteriaFilters")]
		public List<RemoteCriteriaFilter> CriteriaFilters { get; set; }
		[JsonProperty("condition")]
		public String Condition { get; set; }
		[JsonProperty("criterias")]
		public List<RemoteCriteria> Criterias { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaGreaterThan")]
	public class RemoteCriteriaGreaterThan : RemoteCriteria
	{
		[JsonProperty("value")]
		public Object Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaGreaterThanOrEquals")]
	public class RemoteCriteriaGreaterThanOrEquals : RemoteCriteria
	{
		[JsonProperty("value")]
		public Object Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaIn")]
	public class RemoteCriteriaIn : RemoteCriteria
	{
		[JsonProperty("value")]
		public HashSet<Object> Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaIsNotNull")]
	public class RemoteCriteriaIsNotNull : RemoteCriteria
	{
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaIsNull")]
	public class RemoteCriteriaIsNull : RemoteCriteria
	{
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaKey")]
	public abstract class RemoteCriteriaKey
	{
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaLike")]
	public class RemoteCriteriaLike : RemoteCriteria
	{
		[JsonProperty("value")]
		public String Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaNotEquals")]
	public class RemoteCriteriaNotEquals : RemoteCriteria
	{
		[JsonProperty("value")]
		public Object Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaNotIn")]
	public class RemoteCriteriaNotIn : RemoteCriteria
	{
		[JsonProperty("value")]
		public HashSet<Object> Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteCriteriaQueryRequest")]
	public class RemoteCriteriaQueryRequest : RemoteRequest
	{
		[JsonProperty("size")]
		public int Size { get; set; }
		[JsonProperty("offset")]
		public int Offset { get; set; }
		[JsonProperty("order")]
		public List<RemoteOrder> Order { get; set; }
		[JsonProperty("clazz")]
		public String Clazz { get; set; }
		[JsonProperty("criteriaFilter")]
		public RemoteCriteriaFilter CriteriaFilter { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.response.RemoteCriteriaQueryResponse")]
	public class RemoteCriteriaQueryResponse : RemoteResponse
	{
		[JsonProperty("payload")]
		public RemoteList Payload { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteCriteriaQueryTransformerRequest")]
	public class RemoteCriteriaQueryTransformerRequest : RemoteCriteriaQueryRequest
	{
		[JsonProperty("transformer")]
		public RemoteTransformer Transformer { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.response.RemoteCriteriaQueryTransformerResponse")]
	public class RemoteCriteriaQueryTransformerResponse : RemoteResponse
	{
		[JsonProperty("payload")]
		public RemoteTransformerObject Payload { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaSmallerThan")]
	public class RemoteCriteriaSmallerThan : RemoteCriteria
	{
		[JsonProperty("value")]
		public Object Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteCriteriaSmallerThanOrEquals")]
	public class RemoteCriteriaSmallerThanOrEquals : RemoteCriteria
	{
		[JsonProperty("value")]
		public Object Value { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crosssplit.remote.api.RemoteCrossSplitCalculationRequest")]
	public class RemoteCrossSplitCalculationRequest : RemoteRequest
	{
		[JsonProperty("crossSplitConfiguration")]
		public long? CrossSplitConfiguration { get; set; }
		[JsonProperty("massDescriptor")]
		public RemoteMassDescriptor MassDescriptor { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteCrossSplitCalculationTrans")]
	public class RemoteCrossSplitCalculationTrans : RemoteCrossSplitTrans
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteCrossSplitComparisonTrans")]
	public class RemoteCrossSplitComparisonTrans : RemoteCrossSplitTrans
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteCrossSplitTrans")]
	public class RemoteCrossSplitTrans : RemoteTransformation
	{
		[JsonProperty("dataModel")]
		public RemoteDataModelMetadata DataModel { get; set; }
		[JsonProperty("transFigures")]
		public HashSet<RemoteTransFigure> TransFigures { get; set; }
		[JsonProperty("segmentSplitMetadata")]
		public RemoteSplitMetadata SegmentSplitMetadata { get; set; }
		[JsonProperty("channelSplitMetadata")]
		public RemoteSplitMetadata ChannelSplitMetadata { get; set; }
		[JsonProperty("transAttributes")]
		public HashSet<RemoteTransAttribute> TransAttributes { get; set; }
		[JsonProperty("sourceTechnoloy")]
		public RemoteTechnology SourceTechnoloy { get; set; }
		[JsonProperty("targetTechnology")]
		public RemoteTechnology TargetTechnology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.changelog.remote.domain.RemoteCrudChangeLog")]
	public class RemoteCrudChangeLog
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("type")]
		public String Type { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("objectId")]
		public Object ObjectId { get; set; }
		[JsonProperty("operation")]
		public String Operation { get; set; }
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteCsvDeliveryFormat")]
	public class RemoteCsvDeliveryFormat : RemoteFlatfileDeliveryFormat
	{
		[JsonProperty("quote")]
		public char Quote { get; set; }
		[JsonProperty("columnSeparator")]
		public char ColumnSeparator { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteCsvQueryResponse")]
	public class RemoteCsvQueryResponse : RemoteFileResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.exchangerate.remote.RemoteCurrency")]
	public class RemoteCurrency
	{
		[JsonProperty("id")]
		public String Id { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("caption")]
		public String Caption { get; set; }
		[JsonProperty("sign")]
		public String Sign { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.RemoteCustomerOutput")]
	public class RemoteCustomerOutput
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("format")]
		public long? Format { get; set; }
		[JsonProperty("profile")]
		public long? Profile { get; set; }
		[JsonProperty("startPeriod")]
		public long? StartPeriod { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteCustomExpressionColumn")]
	public class RemoteCustomExpressionColumn : RemoteFigureColumn
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("type")]
		public String Type { get; set; }
		[JsonProperty("expression")]
		public String Expression { get; set; }
		[JsonProperty("alias")]
		public String Alias { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dashboard.remote.RemoteDashboard")]
	public abstract class RemoteDashboard
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("dimensionMap1")]
		public String DimensionMap1 { get; set; }
		[JsonProperty("dimensionMap2")]
		public String DimensionMap2 { get; set; }
		[JsonProperty("queryFilterGroup")]
		public RemoteQueryFilterGroup QueryFilterGroup { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteDashboardDefinition")]
	public class RemoteDashboardDefinition : RemoteUserDefinition
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteDashboardNavigatorNode")]
	public class RemoteDashboardNavigatorNode : RemoteUserDefinitionNavigatorNode
	{
		[JsonProperty("dashboard")]
		public RemoteDashboardDefinition Dashboard { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dashboard.remote.RemoteDashboardOutputItem")]
	public abstract class RemoteDashboardOutputItem
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("dashboard")]
		public long? Dashboard { get; set; }
		[JsonProperty("node1")]
		public long? Node1 { get; set; }
		[JsonProperty("node2")]
		public long? Node2 { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dashboard.remote.RemoteDashboardReloadRequest")]
	public abstract class RemoteDashboardReloadRequest : RemoteRequest
	{
		[JsonProperty("dashboard")]
		public long? Dashboard { get; set; }
		[JsonProperty("node1")]
		public long? Node1 { get; set; }
		[JsonProperty("node2")]
		public long? Node2 { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.comment.remote.RemoteDataComment")]
	public class RemoteDataComment : RemoteComment
	{
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.api.RemoteDataExport")]
	public abstract class RemoteDataExport : RemoteRequest
	{
		[JsonProperty("outputItems")]
		public RemoteList OutputItems { get; set; }
		[JsonProperty("sources")]
		public RemoteList Sources { get; set; }
		[JsonProperty("currencies")]
		public List<String> Currencies { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteDataExportPivotTableRequest")]
	public class RemoteDataExportPivotTableRequest : RemoteClientDeliveryPivotTableRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.api.RemoteDataExportResponse")]
	public class RemoteDataExportResponse : RemoteFileResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteDataExportValidationRequest")]
	public class RemoteDataExportValidationRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("outputAttributes")]
		public List<String> OutputAttributes { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.service.index.RemoteDataChangeLog")]
	public class RemoteDataChangeLog
	{
		[JsonProperty("date")]
		public DateTime? Date { get; set; }
		[JsonProperty("username")]
		public String Username { get; set; }
		[JsonProperty("info")]
		public String Info { get; set; }
		[JsonProperty("parentId")]
		public long? ParentId { get; set; }
		[JsonProperty("changeDescriptors")]
		public List<RemoteMassDescriptor> ChangeDescriptors { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.datalocks.remote.RemoteDataLock")]
	public class RemoteDataLock
	{
		[JsonProperty("descriptor")]
		public RemoteDimensionDescriptor Descriptor { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("role")]
		public String Role { get; set; }
		[JsonProperty("lockedBy")]
		public String LockedBy { get; set; }
		[JsonProperty("lockedOn")]
		public DateTime? LockedOn { get; set; }
		[JsonProperty("forbiddenUsers")]
		public HashSet<String> ForbiddenUsers { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteDataModelExportRequest")]
	public class RemoteDataModelExportRequest : RemoteRequest
	{
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("dataModel")]
		public long? DataModel { get; set; }
		[JsonProperty("outputItems")]
		public List<RemoteOutputItem> OutputItems { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteDataModelExportResponse")]
	public class RemoteDataModelExportResponse : RemoteFileResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.model.remote.IRemoteDataModelLoader")]
	public interface IRemoteDataModelLoader
	{
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteDataModelMetadata")]
	public class RemoteDataModelMetadata
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("shipmentMetadata")]
		public long? ShipmentMetadata { get; set; }
		[JsonProperty("descriptorFigures")]
		public HashSet<String> DescriptorFigures { get; set; }
		[JsonProperty("modifierFigures")]
		public HashSet<RemoteModelFigureBundle> ModifierFigures { get; set; }
		[JsonProperty("baseDescriptorMaps")]
		public HashSet<String> BaseDescriptorMaps { get; set; }
		[JsonProperty("modifierDescriptorMaps")]
		public HashSet<String> ModifierDescriptorMaps { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteDataSet")]
	public class RemoteDataSet
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("specification")]
		public RemoteQueryFilterGroup Specification { get; set; }
		[JsonProperty("output")]
		public HashSet<RemoteCheckOutputItem> Output { get; set; }
		[JsonProperty("dataVersion")]
		public String DataVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteDataSetComparisonCheck")]
	public class RemoteDataSetComparisonCheck : RemoteCheck
	{
		[JsonProperty("aliasMap")]
		public RemoteMap AliasMap { get; set; }
		[JsonProperty("primarySet")]
		public long? PrimarySet { get; set; }
		[JsonProperty("secondarySet")]
		public long? SecondarySet { get; set; }
		[JsonProperty("figureDeltas")]
		public HashSet<RemoteFigureDelta> FigureDeltas { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.api.RemoteDataSource")]
	public class RemoteDataSource
	{
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dashboard.remote.RemoteDataStatusDashboard")]
	public class RemoteDataStatusDashboard : RemoteDashboard
	{
	}

	[RemoteName("com.idc_cema.ferda.dashboard.remote.RemoteDataStatusDashboardOutputItem")]
	public class RemoteDataStatusDashboardOutputItem : RemoteDashboardOutputItem
	{
		[JsonProperty("historicalDataStatus")]
		public String HistoricalDataStatus { get; set; }
		[JsonProperty("currentCycleDataStatus")]
		public String CurrentCycleDataStatus { get; set; }
		[JsonProperty("lock")]
		public long? Lock { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.schedule.remote.RemoteDateCategory")]
	public class RemoteDateCategory
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteDbColumn")]
	public class RemoteDbColumn : RemoteColumn
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("type")]
		public String Type { get; set; }
		[JsonProperty("schema")]
		public String Schema { get; set; }
		[JsonProperty("alias")]
		public String Alias { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteDbServer")]
	public class RemoteDbServer : RemoteServer
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteDbTechConvToAggrFigureTrans")]
	public class RemoteDbTechConvToAggrFigureTrans : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteDbTechnologyStructureTrans")]
	public class RemoteDbTechnologyStructureTrans : RemoteTransformation
	{
		[JsonProperty("transformationChainList")]
		public List<RemoteTransformationChain> TransformationChainList { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteDbTechStructureSqlProcedureTrans")]
	public class RemoteDbTechStructureSqlProcedureTrans : RemoteTransformation
	{
		[JsonProperty("procedureName")]
		public String ProcedureName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.rule.remote.RemoteDefaultDimension")]
	public class RemoteDefaultDimension : RemoteDimensionSpecification
	{
		[JsonProperty("specification")]
		public long? Specification { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.client.RemoteDeleteClientDeliveryClientRequest")]
	public class RemoteDeleteClientDeliveryClientRequest : RemoteRequest
	{
		[JsonProperty("clientId")]
		public long? ClientId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.configuration.RemoteDeleteClientDeliveryConfigurationRequest")]
	public class RemoteDeleteClientDeliveryConfigurationRequest : RemoteRequest
	{
		[JsonProperty("configuration")]
		public RemoteClientDeliveryConfiguration Configuration { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.profile.RemoteDeleteClientDeliveryProfileRequest")]
	public class RemoteDeleteClientDeliveryProfileRequest : RemoteRequest
	{
		[JsonProperty("profile")]
		public RemoteClientDeliveryClientProfile Profile { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.report.RemoteDeleteClientDeliveryReportRequest")]
	public class RemoteDeleteClientDeliveryReportRequest : RemoteRequest
	{
		[JsonProperty("report")]
		public RemoteClientDeliveryReport Report { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.comment.remote.RemoteDeleteComment")]
	public class RemoteDeleteComment : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("commentId")]
		public long? CommentId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteDeleteCrudChangeLogRequest")]
	public class RemoteDeleteCrudChangeLogRequest : RemoteRequest
	{
		[JsonProperty("cclId")]
		public long CclId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.api.RemoteDeleteFileRequest")]
	public class RemoteDeleteFileRequest : RemoteRequest
	{
		[JsonProperty("file")]
		public long? File { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.api.RemoteDeleteFileResponse")]
	public class RemoteDeleteFileResponse : RemoteResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteDeleteNavigatorNode")]
	public class RemoteDeleteNavigatorNode : RemoteRequest
	{
		[JsonProperty("node")]
		public long? Node { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteDeleteRequest")]
	public class RemoteDeleteRequest : RemoteRequest
	{
		[JsonProperty("clazz")]
		public String Clazz { get; set; }
		[JsonProperty("payloadId")]
		public Object PayloadId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.response.RemoteDeleteResponse")]
	public class RemoteDeleteResponse : RemoteResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteDeleteShipmentTransformation")]
	public class RemoteDeleteShipmentTransformation : RemoteTransformation
	{
		[JsonProperty("filterGroup")]
		public RemoteQueryFilterGroup FilterGroup { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteDeleteWorkingCopySnapshotsRequest")]
	public class RemoteDeleteWorkingCopySnapshotsRequest : RemoteRequest
	{
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteDeliveryColumn")]
	public abstract class RemoteDeliveryColumn
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("internalId")]
		public long? InternalId { get; set; }
		[JsonProperty("position")]
		public int Position { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteDeliveryFormat")]
	public abstract class RemoteDeliveryFormat
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("createdOn")]
		public DateTime? CreatedOn { get; set; }
		[JsonProperty("startPeriod")]
		public long? StartPeriod { get; set; }
		[JsonProperty("formatType")]
		public long? FormatType { get; set; }
		[JsonProperty("createdBy")]
		public String CreatedBy { get; set; }
		[JsonProperty("product")]
		public long? Product { get; set; }
		[JsonProperty("regionType")]
		public String RegionType { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteDeliveryFormatType")]
	public class RemoteDeliveryFormatType
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteDeliveryTemplate")]
	public abstract class RemoteDeliveryTemplate
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("regionType")]
		public String RegionType { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.domain.RemoteDeliveryTemplateFile")]
	public class RemoteDeliveryTemplateFile : RemoteFerdaFile
	{
	}

	[RemoteName("com.idc_cema.ferda.cron.remote.RemoteDeployBackupData")]
	public class RemoteDeployBackupData : RemoteDeploySnapshotData
	{
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteDeploySnapshotData")]
	public class RemoteDeploySnapshotData : RemoteRequest
	{
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.schema.remote.RemoteDeployTechnologyRequest")]
	public class RemoteDeployTechnologyRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteDerivedAttribute")]
	public abstract class RemoteDerivedAttribute : RemoteAttribute
	{
		[JsonProperty("defaultFilter")]
		public String DefaultFilter { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteDerivedCriteriaFilter")]
	public class RemoteDerivedCriteriaFilter
	{
		[JsonProperty("value")]
		public String Value { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("criteriaFilter")]
		public RemoteCriteriaFilter CriteriaFilter { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteDerivedSpecification")]
	public class RemoteDerivedSpecification
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("defaultValue")]
		public String DefaultValue { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("derivedCriteriaFilter")]
		public HashSet<RemoteDerivedCriteriaFilter> DerivedCriteriaFilter { get; set; }
		[JsonProperty("defaultSameAsAttribute")]
		public String DefaultSameAsAttribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.descriptor.remote.RemoteDescriptor")]
	public class RemoteDescriptor
	{
		[JsonProperty("entries")]
		public HashSet<RemoteEntry> Entries { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteDescriptorRight")]
	public class RemoteDescriptorRight : RemoteRight
	{
		[JsonProperty("descriptor")]
		public RemoteDimensionDescriptor Descriptor { get; set; }
		[JsonProperty("roleGroups")]
		public HashSet<RemoteDescriptorRoleGroup> RoleGroups { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteDescriptorRole")]
	public class RemoteDescriptorRole : RemoteRole
	{
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteDescriptorRoleGroup")]
	public class RemoteDescriptorRoleGroup : RemoteRoleGroup
	{
		[JsonProperty("roles")]
		public HashSet<RemoteDescriptorRole> Roles { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteDimensionBookmarkNavigatorNode")]
	public class RemoteDimensionBookmarkNavigatorNode : RemoteUserDefinitionNavigatorNode
	{
		[JsonProperty("dimensionBookmark")]
		public RemoteDimensionBookmarkUserDefinition DimensionBookmark { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteDimensionBookmarkUserDefinition")]
	public class RemoteDimensionBookmarkUserDefinition : RemoteUserDefinition
	{
		[JsonProperty("filter")]
		public RemoteQueryFilterGroup Filter { get; set; }
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteDimensionColumn")]
	public class RemoteDimensionColumn : RemoteColumn
	{
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
		[JsonProperty("alias")]
		public String Alias { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteDimensionConfigurationDefinition")]
	public class RemoteDimensionConfigurationDefinition : RemoteUserDefinition
	{
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
		[JsonProperty("user")]
		public String User { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionCountRequest")]
	public class RemoteDimensionCountRequest : RemoteCountRequest
	{
		[JsonProperty("dimensionMapId")]
		public String DimensionMapId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionCriteriaQueryRequest")]
	public class RemoteDimensionCriteriaQueryRequest : RemoteCriteriaQueryRequest
	{
		[JsonProperty("dimensionMapId")]
		public String DimensionMapId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.descriptor.remote.RemoteDimensionDescriptor")]
	public class RemoteDimensionDescriptor
	{
		[JsonProperty("id")]
		public long Id { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("nodes")]
		public HashSet<RemoteDimensionEntry> Nodes { get; set; }
		[JsonProperty("additionalEntries")]
		public HashSet<RemoteEntry> AdditionalEntries { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.descriptor.remote.RemoteDimensionEntry")]
	public class RemoteDimensionEntry
	{
		[JsonProperty("nodeId")]
		public long? NodeId { get; set; }
		[JsonProperty("dimensionMapId")]
		public String DimensionMapId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionExport")]
	public class RemoteDimensionExport : RemoteRequest
	{
		[JsonProperty("dimensionDefinition")]
		public RemoteDimensionExportDefinition DimensionDefinition { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionExportDefinition")]
	public class RemoteDimensionExportDefinition
	{
		[JsonProperty("target")]
		public String Target { get; set; }
		[JsonProperty("order")]
		public List<RemoteOrder> Order { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("criteriaFilter")]
		public RemoteCriteriaFilter CriteriaFilter { get; set; }
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
		[JsonProperty("outputItems")]
		public List<RemoteDimensionOutputItem> OutputItems { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionExportResponse")]
	public class RemoteDimensionExportResponse : RemoteFileResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteDimensionCheck")]
	public class RemoteDimensionCheck : RemoteConstraint
	{
		[JsonProperty("map")]
		public String Map { get; set; }
		[JsonProperty("area")]
		public RemoteQueryFilterGroup Area { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionMap")]
	public class RemoteDimensionMap
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public String Id { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("levels")]
		public HashSet<RemoteDimensionMapLevel> Levels { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionMapAttribute")]
	public class RemoteDimensionMapAttribute
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
		[JsonProperty("constraint")]
		public String Constraint { get; set; }
		[JsonProperty("color")]
		public int? Color { get; set; }
		[JsonProperty("linkedDimensionMap")]
		public String LinkedDimensionMap { get; set; }
		[JsonProperty("dimensionMapLevel")]
		public long? DimensionMapLevel { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionMapLevel")]
	public class RemoteDimensionMapLevel
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("level")]
		public int Level { get; set; }
		[JsonProperty("definedAttributes")]
		public List<RemoteDimensionMapAttribute> DefinedAttributes { get; set; }
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
		[JsonProperty("useInView")]
		public String UseInView { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.links.RemoteDimensionMapLink")]
	public class RemoteDimensionMapLink
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("linkFrom")]
		public String LinkFrom { get; set; }
		[JsonProperty("linkTo")]
		public String LinkTo { get; set; }
		[JsonProperty("linkToTechnology")]
		public String LinkToTechnology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionMapUniqueIndexAdd")]
	public class RemoteDimensionMapUniqueIndexAdd : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionMapUniqueIndexDrop")]
	public class RemoteDimensionMapUniqueIndexDrop : RemoteRequest
	{
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
		[JsonProperty("tehchnology")]
		public String Tehchnology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionMergeLog")]
	public class RemoteDimensionMergeLog
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("mergedBy")]
		public String MergedBy { get; set; }
		[JsonProperty("mergedOn")]
		public DateTime? MergedOn { get; set; }
		[JsonProperty("details")]
		public HashSet<RemoteDimensionMergeLogDetail> Details { get; set; }
		[JsonProperty("requestId")]
		public String RequestId { get; set; }
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionMergeLogDetail")]
	public class RemoteDimensionMergeLogDetail
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("newValue")]
		public String NewValue { get; set; }
		[JsonProperty("oldValue")]
		public String OldValue { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionNode")]
	public class RemoteDimensionNode
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attributes")]
		public HashSet<RemoteDimensionNodeAttributeValue> Attributes { get; set; }
		[JsonProperty("order")]
		public long? Order { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("master")]
		public long? Master { get; set; }
		[JsonProperty("modelWorkflow")]
		public String ModelWorkflow { get; set; }
		[JsonProperty("lastUpdatedBy")]
		public String LastUpdatedBy { get; set; }
		[JsonProperty("createdBy")]
		public String CreatedBy { get; set; }
		[JsonProperty("dimensionMapLevel")]
		public long? DimensionMapLevel { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionNodeAttributeValue")]
	public class RemoteDimensionNodeAttributeValue
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attribute")]
		public long? Attribute { get; set; }
		[JsonProperty("booleanValue")]
		public bool BooleanValue { get; set; }
		[JsonProperty("longValue")]
		public long? LongValue { get; set; }
		[JsonProperty("stringValue")]
		public String StringValue { get; set; }
		[JsonProperty("doubleValue")]
		public Double DoubleValue { get; set; }
		[JsonProperty("dmaDimIdValue")]
		public long? DmaDimIdValue { get; set; }
		[JsonProperty("timestampValue")]
		public DateTime? TimestampValue { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.links.RemoteDimensionNodeLink")]
	public class RemoteDimensionNodeLink
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("nodeFrom")]
		public long? NodeFrom { get; set; }
		[JsonProperty("nodeTo")]
		public long? NodeTo { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionOutputItem")]
	public class RemoteDimensionOutputItem : RemoteCheckOutputItem
	{
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionPath")]
	public class RemoteDimensionPath
	{
		[JsonProperty("path")]
		public HashSet<RemoteDimensionNode> Path { get; set; }
		[JsonProperty("dimensionMapId")]
		public String DimensionMapId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteDimensionQueryFilter")]
	public class RemoteDimensionQueryFilter : RemoteQueryFilter
	{
		[JsonProperty("nodeIds")]
		public HashSet<long?> NodeIds { get; set; }
		[JsonProperty("dimensionMapId")]
		public String DimensionMapId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.rule.remote.RemoteDimensionSpecification")]
	public abstract class RemoteDimensionSpecification : RemoteSpecification
	{
		[JsonProperty("map")]
		public String Map { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteDimensionUniqueCheck")]
	public class RemoteDimensionUniqueCheck : RemoteConstraint
	{
		[JsonProperty("attributes")]
		public HashSet<String> Attributes { get; set; }
		[JsonProperty("map")]
		public String Map { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionUsageRequest")]
	public class RemoteDimensionUsageRequest : RemoteRequest
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("attributeValues")]
		public List<String> AttributeValues { get; set; }
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteDimensionUsageResponse")]
	public class RemoteDimensionUsageResponse : RemoteFileResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.file.remote.api.RemoteDownloadFileRequest")]
	public class RemoteDownloadFileRequest : RemoteRequest
	{
		[JsonProperty("file")]
		public long? File { get; set; }
		[JsonProperty("offset")]
		public long Offset { get; set; }
		[JsonProperty("bufferSize")]
		public int BufferSize { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.api.RemoteDownloadFileResponse")]
	public class RemoteDownloadFileResponse : RemoteResponse
	{
		[JsonProperty("data")]
		public byte[] Data { get; set; }
		[JsonProperty("hash")]
		public String Hash { get; set; }
		[JsonProperty("bufferSize")]
		public int BufferSize { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.cron.remote.RemoteDumpBackupData")]
	public class RemoteDumpBackupData : RemoteDumpSnapshotData
	{
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteDumpSnapshotData")]
	public class RemoteDumpSnapshotData : RemoteRequest
	{
		[JsonProperty("filename")]
		public String Filename { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("schema")]
		public HashSet<String> Schema { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteDuplicateColumnTrans")]
	public class RemoteDuplicateColumnTrans : RemoteTransformation
	{
		[JsonProperty("originalAttribute")]
		public String OriginalAttribute { get; set; }
		[JsonProperty("duplicatedAttributes")]
		public HashSet<String> DuplicatedAttributes { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteEditableSqlDerivedAttribute")]
	public class RemoteEditableSqlDerivedAttribute : RemoteSqlDerivedAttribute
	{
	}

	[RemoteName("com.idc_cema.ferda.common.remote.RemoteEntry")]
	public class RemoteEntry
	{
		[JsonProperty("value")]
		public Object Value { get; set; }
		[JsonProperty("key")]
		public String Key { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteEntrySheetDefinition")]
	public class RemoteEntrySheetDefinition : RemoteUserDefinition
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteEntrySheetDefinitionNavigatorNode")]
	public class RemoteEntrySheetDefinitionNavigatorNode : RemoteUserDefinitionNavigatorNode
	{
		[JsonProperty("definition")]
		public RemoteEntrySheetDefinition Definition { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateDataSetComparisonCheckResponse")]
	public class RemoteEvaluateDataSetComparisonCheckResponse : RemoteEvaluateCheckResponse
	{
		[JsonProperty("output")]
		public RemoteComparisonCheckOutput Output { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateDimensionCheck")]
	public class RemoteEvaluateDimensionCheck : RemoteEvaluateCheck
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateDimensionCheckResponse")]
	public class RemoteEvaluateDimensionCheckResponse : RemoteEvaluateCheckResponse
	{
		[JsonProperty("paths")]
		public List<RemoteDimensionPath> Paths { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateDimensionUniqueCheck")]
	public class RemoteEvaluateDimensionUniqueCheck : RemoteEvaluateCheck
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateDimensionUniqueCheckResponse")]
	public class RemoteEvaluateDimensionUniqueCheckResponse : RemoteEvaluateCheckResponse
	{
		[JsonProperty("paths")]
		public List<RemoteDimensionPath> Paths { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateGainedPointsCheck")]
	public class RemoteEvaluateGainedPointsCheck : RemoteEvaluateCheck
	{
		[JsonProperty("dataVersion")]
		public String DataVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateGainedPointsCheckResponse")]
	public class RemoteEvaluateGainedPointsCheckResponse : RemoteEvaluateCheckResponse
	{
		[JsonProperty("shipments")]
		public List<RemoteFigureRecord> Shipments { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateGrowthCheckResponse")]
	public class RemoteEvaluateGrowthCheckResponse : RemoteEvaluateCheckResponse
	{
		[JsonProperty("output")]
		public RemoteGrowthCheckOutput Output { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateCheck")]
	public abstract class RemoteEvaluateCheck : RemoteRequest
	{
		[JsonProperty("check")]
		public long? Check { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateCheckResponse")]
	public abstract class RemoteEvaluateCheckResponse : RemoteResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateShareCheck")]
	public class RemoteEvaluateShareCheck : RemoteEvaluateCheck
	{
		[JsonProperty("dataVersion")]
		public String DataVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateShareCheckResponse")]
	public class RemoteEvaluateShareCheckResponse : RemoteEvaluateCheckResponse
	{
		[JsonProperty("shipments")]
		public List<RemoteFigureRecord> Shipments { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateSpecifiedCheck")]
	public class RemoteEvaluateSpecifiedCheck : RemoteEvaluateCheck
	{
		[JsonProperty("userSpecification")]
		public RemoteQueryFilterGroup UserSpecification { get; set; }
		[JsonProperty("dataVersion")]
		public String DataVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteEvaluateSpecifiedCheckResponse")]
	public class RemoteEvaluateSpecifiedCheckResponse : RemoteEvaluateCheckResponse
	{
		[JsonProperty("shipments")]
		public HashSet<RemoteFigureRecord> Shipments { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteExcelDeliveryTemplate")]
	public class RemoteExcelDeliveryTemplate : RemoteDeliveryTemplate
	{
		[JsonProperty("file")]
		public long? File { get; set; }
		[JsonProperty("placeholders")]
		public HashSet<RemotePlaceholder> Placeholders { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.RemoteExecuteAdHocTransformation")]
	public class RemoteExecuteAdHocTransformation : RemoteExecuteTransformationRequest
	{
		[JsonProperty("transformationChain")]
		public RemoteTransformationChain TransformationChain { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.production.RemoteExecuteClientDelivery")]
	public class RemoteExecuteClientDelivery : RemoteRequest
	{
		[JsonProperty("executionQFG")]
		public RemoteQueryFilterGroup ExecutionQFG { get; set; }
		[JsonProperty("targetDatabase")]
		public String TargetDatabase { get; set; }
		[JsonProperty("clientDeliveryConfigurationId")]
		public long? ClientDeliveryConfigurationId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.api.RemoteExecuteContract")]
	public class RemoteExecuteContract : RemoteRequest
	{
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("contract")]
		public long? Contract { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.api.RemoteExecuteDeliverable")]
	public class RemoteExecuteDeliverable : RemoteRequest
	{
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("deliverable")]
		public long? Deliverable { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.api.RemoteExecuteDeliverableResponse")]
	public class RemoteExecuteDeliverableResponse : RemoteFileResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.api.RemoteExecuteFormat")]
	public class RemoteExecuteFormat : RemoteRequest
	{
		[JsonProperty("format")]
		public long? Format { get; set; }
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteExecuteJob")]
	public class RemoteExecuteJob : RemoteRequest
	{
		[JsonProperty("databaseName")]
		public String DatabaseName { get; set; }
		[JsonProperty("job")]
		public long? Job { get; set; }
		[JsonProperty("parameterValues")]
		public RemoteMassDescriptor ParameterValues { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteExecuteJobResponse")]
	public class RemoteExecuteJobResponse : RemoteFileResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.RemoteExecuteJobTransRequest")]
	public class RemoteExecuteJobTransRequest : RemoteRequest
	{
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("transformations")]
		public List<RemoteTransformation> Transformations { get; set; }
		[JsonProperty("tables")]
		public List<RemoteTransTable> Tables { get; set; }
		[JsonProperty("targetFilter")]
		public RemoteCriteriaFilter TargetFilter { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.RemoteExecuteJobTransResponse")]
	public class RemoteExecuteJobTransResponse : RemoteResponse
	{
		[JsonProperty("tables")]
		public List<RemoteTransTable> Tables { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.RemoteExecutePartitionTransConfigurationRequest")]
	public class RemoteExecutePartitionTransConfigurationRequest : RemoteRequest
	{
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("configuration")]
		public long? Configuration { get; set; }
		[JsonProperty("topTransformationInfo")]
		public RemoteTopTransformationInfo TopTransformationInfo { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.RemoteExecuteTransConfigurationRequest")]
	public class RemoteExecuteTransConfigurationRequest : RemoteExecuteTransformationRequest
	{
		[JsonProperty("configuration")]
		public long? Configuration { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.RemoteExecuteTransformation")]
	public class RemoteExecuteTransformation : RemoteExecuteTransformationRequest
	{
		[JsonProperty("transformationChain")]
		public long? TransformationChain { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.RemoteExecuteTransformationRequest")]
	public abstract class RemoteExecuteTransformationRequest : RemoteRequest
	{
		[JsonProperty("globalFilter")]
		public RemoteQueryFilterGroup GlobalFilter { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.exchangerate.remote.RemoteExchangeRate")]
	public class RemoteExchangeRate
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("currency")]
		public String Currency { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteExportTableToCsvTransformation")]
	public class RemoteExportTableToCsvTransformation : RemoteTransformation
	{
		[JsonProperty("rowLimit")]
		public int RowLimit { get; set; }
		[JsonProperty("dataSeparator")]
		public char DataSeparator { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.domain.RemoteFerdaFile")]
	public abstract class RemoteFerdaFile
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("size")]
		public long Size { get; set; }
		[JsonProperty("hash")]
		public String Hash { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteFieldOrder")]
	public class RemoteFieldOrder
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("order")]
		public int Order { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("visibilityType")]
		public String VisibilityType { get; set; }
		[JsonProperty("formula")]
		public String Formula { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteFigure")]
	public class RemoteFigure
	{
		[JsonProperty("id")]
		public String Id { get; set; }
		[JsonProperty("type")]
		public String Type { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("color")]
		public int Color { get; set; }
		[JsonProperty("caption")]
		public String Caption { get; set; }
		[JsonProperty("aggregatable")]
		public bool Aggregatable { get; set; }
		[JsonProperty("decimalPlaces")]
		public int DecimalPlaces { get; set; }
		[JsonProperty("koeficient")]
		public int Koeficient { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.RemoteFigureAxisItem")]
	public class RemoteFigureAxisItem : RemotePivotAxisItem
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.formula.remote.cache.RemoteFigureCacheOperationRequest")]
	public class RemoteFigureCacheOperationRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("operation")]
		public String Operation { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.formula.remote.cache.RemoteFigureCacheReloadResponse")]
	public class RemoteFigureCacheReloadResponse : RemoteResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteFigureColumn")]
	public class RemoteFigureColumn : RemoteColumn
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("figureFormula")]
		public String FigureFormula { get; set; }
		[JsonProperty("alias")]
		public String Alias { get; set; }
		[JsonProperty("aggregateFunction")]
		public String AggregateFunction { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteFigureCriteria")]
	public class RemoteFigureCriteria
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("negligibleValue")]
		public double NegligibleValue { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteFigureDefinition")]
	public class RemoteFigureDefinition
	{
		[JsonProperty("value")]
		public double Value { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteFigureDeliveryColumn")]
	public class RemoteFigureDeliveryColumn : RemoteDeliveryColumn
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("denominator")]
		public String Denominator { get; set; }
		[JsonProperty("currency")]
		public String Currency { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteFigureDelta")]
	public class RemoteFigureDelta
	{
		[JsonProperty("value")]
		public Double Value { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteFigureDerivative")]
	public class RemoteFigureDerivative
	{
		[JsonProperty("value")]
		public Double Value { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("operation")]
		public String Operation { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteFigureEntry")]
	public class RemoteFigureEntry
	{
		[JsonProperty("value")]
		public Double Value { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteFigureChange")]
	public class RemoteFigureChange : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("what")]
		public String What { get; set; }
		[JsonProperty("changeDsc")]
		public RemoteMassDescriptor ChangeDsc { get; set; }
		[JsonProperty("defaultDsc")]
		public RemoteMassDescriptor DefaultDsc { get; set; }
		[JsonProperty("newFigure")]
		public double NewFigure { get; set; }
		[JsonProperty("growthToKeep")]
		public String GrowthToKeep { get; set; }
		[JsonProperty("periodsToKeep")]
		public int PeriodsToKeep { get; set; }
		[JsonProperty("dataVersion")]
		public String DataVersion { get; set; }
		[JsonProperty("currencyVersion")]
		public long? CurrencyVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteFigureKey")]
	public class RemoteFigureKey : RemoteCriteriaKey
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteFigureOperation")]
	public class RemoteFigureOperation
	{
		[JsonProperty("value")]
		public Double Value { get; set; }
		[JsonProperty("figure")]
		public RemoteFigure Figure { get; set; }
		[JsonProperty("operation")]
		public String Operation { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.dto.RemoteFigureOutputItem")]
	public class RemoteFigureOutputItem : RemoteOutputItem
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("denominator")]
		public String Denominator { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteFigurePack")]
	public class RemoteFigurePack
	{
		[JsonProperty("entries")]
		public HashSet<RemoteFigureEntry> Entries { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteFigureQueryFilter")]
	public class RemoteFigureQueryFilter : RemoteQueryFilter
	{
		[JsonProperty("value")]
		public String Value { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteFigureRecord")]
	public class RemoteFigureRecord
	{
		[JsonProperty("descriptor")]
		public RemoteDescriptor Descriptor { get; set; }
		[JsonProperty("figurePack")]
		public RemoteFigurePack FigurePack { get; set; }
		[JsonProperty("derivativePack")]
		public RemoteMultiFigureDerivativePack DerivativePack { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteFigureRenameMapping")]
	public class RemoteFigureRenameMapping : RemoteITransRenameMapping
	{
		[JsonProperty("target")]
		public String Target { get; set; }
		[JsonProperty("source")]
		public String Source { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.api.RemoteFileReference")]
	public class RemoteFileReference
	{
		[JsonProperty("filename")]
		public String Filename { get; set; }
		[JsonProperty("filePath")]
		public String FilePath { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.common.remote.RemoteFileResponse")]
	public class RemoteFileResponse : RemoteResponse
	{
		[JsonProperty("resultFilenames")]
		public HashSet<String> ResultFilenames { get; set; }
		[JsonProperty("downloadPattern")]
		public String DownloadPattern { get; set; }
		[JsonProperty("resultMessage")]
		public String ResultMessage { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteFilterItem")]
	public class RemoteFilterItem
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteFlatfile")]
	public class RemoteFlatfile
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("format")]
		public long? Format { get; set; }
		[JsonProperty("columns")]
		public HashSet<RemoteDeliveryColumn> Columns { get; set; }
		[JsonProperty("resultFileName")]
		public String ResultFileName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.api.RemoteFlatFileDataExport")]
	public class RemoteFlatFileDataExport : RemoteDataExport
	{
		[JsonProperty("type")]
		public String Type { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteFlatfileDeliveryFormat")]
	public abstract class RemoteFlatfileDeliveryFormat : RemoteDeliveryFormat
	{
		[JsonProperty("flatfiles")]
		public HashSet<long?> Flatfiles { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteFlushTemporaryTableToFlatfile")]
	public class RemoteFlushTemporaryTableToFlatfile : RemoteRequest
	{
		[JsonProperty("filename")]
		public String Filename { get; set; }
		[JsonProperty("flatfile")]
		public RemoteFlatfile Flatfile { get; set; }
		[JsonProperty("config")]
		public RemoteMap Config { get; set; }
		[JsonProperty("headerRename")]
		public RemoteMap HeaderRename { get; set; }
		[JsonProperty("temporaryTable")]
		public long? TemporaryTable { get; set; }
	}
    
    [RemoteName("com.idc_cema.ferda.welcomescreen.remote.RemoteMap")]
    public class RemoteMap
    {
    }

    [RemoteName("com.idc_cema.ferda.welcomescreen.remote.RemoteFolder")]
	public abstract class RemoteFolder
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
		[JsonProperty("img")]
		public String Img { get; set; }
		[JsonProperty("groups")]
		public List<RemoteTechnologyGroup> Groups { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.forecasting.remote.priceband.domain.RemoteForecastCalculationConfiguration")]
	public class RemoteForecastCalculationConfiguration
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("splitMetadata")]
		public long? SplitMetadata { get; set; }
		[JsonProperty("splitMap")]
		public long? SplitMap { get; set; }
		[JsonProperty("splitMapLevel")]
		public long? SplitMapLevel { get; set; }
		[JsonProperty("figures")]
		public HashSet<String> Figures { get; set; }
		[JsonProperty("forecastTechnologyId")]
		public String ForecastTechnologyId { get; set; }
		[JsonProperty("historicalTechnologyId")]
		public String HistoricalTechnologyId { get; set; }
		[JsonProperty("periodAttribute")]
		public String PeriodAttribute { get; set; }
		[JsonProperty("descriptorAttributes")]
		public HashSet<String> DescriptorAttributes { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.formula.remote.RemoteFormula")]
	public class RemoteFormula
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("implementation")]
		public String Implementation { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteGainedPointPivotOperation")]
	public class RemoteGainedPointPivotOperation : RemotePivotChangeOperation
	{
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteGainedPointPivotOperationDef")]
	public class RemoteGainedPointPivotOperationDef : RemotePivotChangeOperationDef
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteGainedPointsCheck")]
	public class RemoteGainedPointsCheck : RemoteCombinationCheck
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("gainedPointsBy")]
		public String GainedPointsBy { get; set; }
		[JsonProperty("minimumGainedPoints")]
		public double MinimumGainedPoints { get; set; }
		[JsonProperty("maximumGainedPoints")]
		public double MaximumGainedPoints { get; set; }
		[JsonProperty("growthType")]
		public String GrowthType { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGenerateAttributeRequest")]
	public abstract class RemoteGenerateAttributeRequest : RemoteRequest
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.auth.remote.RemoteGenerateAuthKeyRequest")]
	public class RemoteGenerateAuthKeyRequest : RemoteRequest
	{
		[JsonProperty("username")]
		public String Username { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.auth.remote.RemoteGenerateAuthKeyResponse")]
	public class RemoteGenerateAuthKeyResponse : RemoteResponse
	{
		[JsonProperty("authKey")]
		public String AuthKey { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGenerateCriteriaDerivedAttributeRequest")]
	public class RemoteGenerateCriteriaDerivedAttributeRequest : RemoteGenerateAttributeRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteGenerateProfileFileRequest")]
	public class RemoteGenerateProfileFileRequest : RemoteRequest
	{
		[JsonProperty("group")]
		public long? Group { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteGenerateProfileFileResponse")]
	public class RemoteGenerateProfileFileResponse : RemoteResponse
	{
		[JsonProperty("file")]
		public long? File { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteGenerateProfileRequest")]
	public class RemoteGenerateProfileRequest : RemoteRequest
	{
		[JsonProperty("file")]
		public long? File { get; set; }
		[JsonProperty("group")]
		public long? Group { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGenerateSqlDerivedAttributeRequest")]
	public class RemoteGenerateSqlDerivedAttributeRequest : RemoteGenerateAttributeRequest
	{
		[JsonProperty("inputParams")]
		public List<String> InputParams { get; set; }
		[JsonProperty("declare")]
		public String Declare { get; set; }
		[JsonProperty("body")]
		public String Body { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteGenerateTechnologyProfileRequest")]
	public class RemoteGenerateTechnologyProfileRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("groups")]
		public List<long?> Groups { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGenerateTopNAttributeRequest")]
	public class RemoteGenerateTopNAttributeRequest : RemoteGenerateAttributeRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.procedure.RemoteGenerateTransStoredProcedureRequest")]
	public class RemoteGenerateTransStoredProcedureRequest : RemoteTransStoredProcedureRequest
	{
		[JsonProperty("declare")]
		public String Declare { get; set; }
		[JsonProperty("body")]
		public String Body { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.configuration.RemoteGetAllClientDeliveryConfigurationRequest")]
	public class RemoteGetAllClientDeliveryConfigurationRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("client")]
		public RemoteClientDeliveryClient Client { get; set; }
		[JsonProperty("profile")]
		public RemoteClientDeliveryClientProfile Profile { get; set; }
		[JsonProperty("report")]
		public RemoteClientDeliveryReport Report { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.configuration.RemoteGetAllClientDeliveryConfigurationResponse")]
	public class RemoteGetAllClientDeliveryConfigurationResponse : RemoteResponse
	{
		[JsonProperty("configurations")]
		public HashSet<RemoteClientDeliveryConfiguration> Configurations { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.profile.RemoteGetAllClientDeliveryProfileRequest")]
	public class RemoteGetAllClientDeliveryProfileRequest : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.profile.RemoteGetAllClientDeliveryProfileResponse")]
	public class RemoteGetAllClientDeliveryProfileResponse : RemoteResponse
	{
		[JsonProperty("profiles")]
		public HashSet<RemoteClientDeliveryClientProfile> Profiles { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.report.RemoteGetAllClientDeliveryReportRequest")]
	public class RemoteGetAllClientDeliveryReportRequest : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.report.RemoteGetAllClientDeliveryReportResponse")]
	public class RemoteGetAllClientDeliveryReportResponse : RemoteResponse
	{
		[JsonProperty("reports")]
		public HashSet<RemoteClientDeliveryReport> Reports { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGetAttributeStoredProcedureRequest")]
	public class RemoteGetAttributeStoredProcedureRequest : RemoteGetStoredProcedureRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGetAttributeStoredSqlProcedureRequest")]
	public class RemoteGetAttributeStoredSqlProcedureRequest : RemoteGetStoredProcedureRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGetAttributeValues")]
	public class RemoteGetAttributeValues : RemoteRequest
	{
		[JsonProperty("descriptor")]
		public RemoteMassDescriptor Descriptor { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("versions")]
		public HashSet<String> Versions { get; set; }
		[JsonProperty("technologies")]
		public HashSet<String> Technologies { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGetAttributeValuesResponse")]
	public class RemoteGetAttributeValuesResponse : RemoteResponse
	{
		[JsonProperty("attributeValue")]
		public HashSet<String> AttributeValue { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.client.RemoteGetClientDeliveryClientRequest")]
	public class RemoteGetClientDeliveryClientRequest : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.client.RemoteGetClientDeliveryClientResponse")]
	public class RemoteGetClientDeliveryClientResponse : RemoteResponse
	{
		[JsonProperty("clients")]
		public HashSet<RemoteClientDeliveryClient> Clients { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.configuration.RemoteGetClientDeliveryConfigurationRequest")]
	public class RemoteGetClientDeliveryConfigurationRequest : RemoteRequest
	{
		[JsonProperty("configuration")]
		public RemoteClientDeliveryConfiguration Configuration { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.configuration.RemoteGetClientDeliveryConfigurationResponse")]
	public class RemoteGetClientDeliveryConfigurationResponse : RemoteResponse
	{
		[JsonProperty("configuration")]
		public RemoteClientDeliveryConfiguration Configuration { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.profile.RemoteGetClientDeliveryProfileRequest")]
	public class RemoteGetClientDeliveryProfileRequest : RemoteRequest
	{
		[JsonProperty("profile")]
		public RemoteClientDeliveryClientProfile Profile { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.profile.RemoteGetClientDeliveryProfileResponse")]
	public class RemoteGetClientDeliveryProfileResponse : RemoteResponse
	{
		[JsonProperty("profile")]
		public RemoteClientDeliveryClientProfile Profile { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.report.RemoteGetClientDeliveryReportRequest")]
	public class RemoteGetClientDeliveryReportRequest : RemoteRequest
	{
		[JsonProperty("report")]
		public RemoteClientDeliveryReport Report { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.report.RemoteGetClientDeliveryReportResponse")]
	public class RemoteGetClientDeliveryReportResponse : RemoteResponse
	{
		[JsonProperty("report")]
		public RemoteClientDeliveryReport Report { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.comment.remote.RemoteGetComment")]
	public class RemoteGetComment : RemoteRequest
	{
		[JsonProperty("descriptor")]
		public RemoteMassDescriptor Descriptor { get; set; }
		[JsonProperty("comment")]
		public RemoteComment Comment { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("username")]
		public String Username { get; set; }
		[JsonProperty("fromDate")]
		public DateTime? FromDate { get; set; }
		[JsonProperty("limit")]
		public int Limit { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.comment.remote.RemoteGetCommentResponse")]
	public class RemoteGetCommentResponse : RemoteResponse
	{
		[JsonProperty("comments")]
		public HashSet<RemoteComment> Comments { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.service.index.RemoteGetDataChange")]
	public class RemoteGetDataChange : RemoteRequest
	{
		[JsonProperty("descriptor")]
		public RemoteMassDescriptor Descriptor { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("username")]
		public String Username { get; set; }
		[JsonProperty("parentId")]
		public long?[] ParentId { get; set; }
		[JsonProperty("fromDate")]
		public DateTime? FromDate { get; set; }
		[JsonProperty("toDate")]
		public DateTime? ToDate { get; set; }
		[JsonProperty("limit")]
		public int Limit { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.service.index.RemoteGetDataChangeResponse")]
	public class RemoteGetDataChangeResponse : RemoteResponse
	{
		[JsonProperty("changes")]
		public List<RemoteDataChangeLog> Changes { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.api.RemoteGetFileReferenceRequest")]
	public class RemoteGetFileReferenceRequest : RemoteRequest
	{
		[JsonProperty("file")]
		public long? File { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.api.RemoteGetFileReferenceResponse")]
	public class RemoteGetFileReferenceResponse : RemoteResponse
	{
		[JsonProperty("fileReference")]
		public RemoteFileReference FileReference { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGetMetadata")]
	public class RemoteGetMetadata : RemoteRequest
	{
		[JsonProperty("technologies")]
		public HashSet<String> Technologies { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGetMetadataResponse")]
	public class RemoteGetMetadataResponse : RemoteResponse
	{
		[JsonProperty("technologyMetadata")]
		public HashSet<RemoteTechnologyMetadata> TechnologyMetadata { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteGetNavigatorTree")]
	public class RemoteGetNavigatorTree : RemoteRequest
	{
		[JsonProperty("root")]
		public long? Root { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteGetNavigatorTreeResponse")]
	public class RemoteGetNavigatorTreeResponse : RemoteResponse
	{
		[JsonProperty("tree")]
		public HashSet<RemoteNavigatorNode> Tree { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.RemoteGetPivotFileResponse")]
	public class RemoteGetPivotFileResponse : RemoteFileResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.RemoteGetPivotRequest")]
	public class RemoteGetPivotRequest : RemoteRequest
	{
		[JsonProperty("output")]
		public String Output { get; set; }
		[JsonProperty("pivotDefinition")]
		public RemotePivotDef PivotDefinition { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.RemoteGetPivotResponse")]
	public class RemoteGetPivotResponse : RemoteResponse
	{
		[JsonProperty("pivot")]
		public RemotePivot Pivot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteGetRequest")]
	public class RemoteGetRequest : RemoteRequest
	{
		[JsonProperty("clazz")]
		public String Clazz { get; set; }
		[JsonProperty("payloadId")]
		public Object PayloadId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.response.RemoteGetResponse")]
	public class RemoteGetResponse : RemoteResponse
	{
		[JsonProperty("payload")]
		public Object Payload { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteGetScheduledJobStatisticRequest")]
	public class RemoteGetScheduledJobStatisticRequest : RemoteRequest
	{
		[JsonProperty("user")]
		public String User { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteGetScheduledJobStatisticResponse")]
	public class RemoteGetScheduledJobStatisticResponse : RemoteResponse
	{
		[JsonProperty("queued")]
		public int Queued { get; set; }
		[JsonProperty("inProgress")]
		public int InProgress { get; set; }
		[JsonProperty("done")]
		public int Done { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGetStoredProcedureDefinitionResponse")]
	public class RemoteGetStoredProcedureDefinitionResponse : RemoteGetStoredProcedureResponse
	{
		[JsonProperty("inputParams")]
		public List<String> InputParams { get; set; }
		[JsonProperty("declare")]
		public String Declare { get; set; }
		[JsonProperty("body")]
		public String Body { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGetStoredProcedureRequest")]
	public abstract class RemoteGetStoredProcedureRequest : RemoteRequest
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGetStoredProcedureResponse")]
	public abstract class RemoteGetStoredProcedureResponse : RemoteResponse
	{
		[JsonProperty("fullName")]
		public String FullName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGetStoredProcedureSqlResponse")]
	public class RemoteGetStoredProcedureSqlResponse : RemoteGetStoredProcedureResponse
	{
		[JsonProperty("function")]
		public String Function { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.procedure.RemoteGetTransStoredProcedureRequest")]
	public class RemoteGetTransStoredProcedureRequest : RemoteTransStoredProcedureRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteGlobalRight")]
	public class RemoteGlobalRight : RemoteRight
	{
		[JsonProperty("roleGroup")]
		public RemoteGlobalRoleGroup RoleGroup { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteGlobalRole")]
	public class RemoteGlobalRole : RemoteRole
	{
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteGlobalRoleGroup")]
	public class RemoteGlobalRoleGroup : RemoteRoleGroup
	{
		[JsonProperty("roles")]
		public HashSet<RemoteGlobalRole> Roles { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteGraphDefinition")]
	public class RemoteGraphDefinition : RemoteUserDefinition
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteGraphDefinitionNavigatorNode")]
	public class RemoteGraphDefinitionNavigatorNode : RemoteUserDefinitionNavigatorNode
	{
		[JsonProperty("definition")]
		public RemoteGraphDefinition Definition { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteGroupAttribute")]
	public class RemoteGroupAttribute : RemoteAttribute
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("group")]
		public long? Group { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteGroupFileMapping")]
	public class RemoteGroupFileMapping
	{
		[JsonProperty("group")]
		public long? Group { get; set; }
		[JsonProperty("sqlLiteFile")]
		public long? SqlLiteFile { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteGroupingDuplicatedRecordsTransformation")]
	public class RemoteGroupingDuplicatedRecordsTransformation : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteGrowthCheck")]
	public class RemoteGrowthCheck : RemoteCombinationCheck
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("growthType")]
		public String GrowthType { get; set; }
		[JsonProperty("growthLimits")]
		public List<RemoteCheckLimitFigure> GrowthLimits { get; set; }
		[JsonProperty("currencyVersion")]
		public long? CurrencyVersion { get; set; }
		[JsonProperty("minimumGrowthRate")]
		public Double MinimumGrowthRate { get; set; }
		[JsonProperty("maximumGrowthRate")]
		public Double MaximumGrowthRate { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteGrowthCheckOutput")]
	public class RemoteGrowthCheckOutput : RemoteCheckOutput
	{
		[JsonProperty("rows")]
		public HashSet<RemoteGrowthCheckRow> Rows { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteGrowthCheckRow")]
	public class RemoteGrowthCheckRow : RemoteCheckRow
	{
		[JsonProperty("baseFigurePack")]
		public RemoteNewFigurePack BaseFigurePack { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteGrowthPivotOperation")]
	public class RemoteGrowthPivotOperation : RemotePivotChangeOperation
	{
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteGrowthPivotOperationDef")]
	public class RemoteGrowthPivotOperationDef : RemotePivotChangeOperationDef
	{
	}

	[RemoteName("com.idc_cema.ferda.comment.remote.RemoteGuidance")]
	public class RemoteGuidance : RemoteComment
	{
		[JsonProperty("type")]
		public String Type { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.welcomescreen.remote.RemoteGuidanceFolder")]
	public class RemoteGuidanceFolder : RemoteFolder
	{
	}

	[RemoteName("com.idc_cema.ferda.common.remote.RemoteChannelRequest")]
	public class RemoteChannelRequest
	{
		[JsonProperty("id")]
		public String Id { get; set; }
		[JsonProperty("requests")]
		public HashSet<RemoteRequest> Requests { get; set; }
		[JsonProperty("switches")]
		public ClientSwitch[] Switches { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.common.remote.RemoteChannelResponse")]
	public class RemoteChannelResponse
	{
		[JsonProperty("id")]
		public String Id { get; set; }
		[JsonProperty("responses")]
		public List<RemoteResponse> Responses { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteCheck")]
	public abstract class RemoteCheck
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("checkLevel")]
		public String CheckLevel { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteCheckLimitFigure")]
	public class RemoteCheckLimitFigure
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("figureLimit")]
		public Double FigureLimit { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteCheckNavigatorNode")]
	public class RemoteCheckNavigatorNode : RemoteNavigatorNode
	{
		[JsonProperty("check")]
		public long? Check { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteCheckOutput")]
	public abstract class RemoteCheckOutput
	{
		[JsonProperty("check")]
		public RemoteCheck Check { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteCheckOutputItem")]
	public class RemoteCheckOutputItem
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteCheckRow")]
	public abstract class RemoteCheckRow
	{
		[JsonProperty("descriptor")]
		public RemoteDimensionDescriptor Descriptor { get; set; }
		[JsonProperty("figurePack")]
		public RemoteNewFigurePack FigurePack { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.check.RemoteCheckShipmentConsistencyRequest")]
	public class RemoteCheckShipmentConsistencyRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("filterGroup")]
		public RemoteCriteriaFilter FilterGroup { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.check.RemoteCheckShipmentConsistencyResponse")]
	public class RemoteCheckShipmentConsistencyResponse : RemoteFileResponse
	{
		[JsonProperty("errorCount")]
		public int ErrorCount { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.cron.remote.RemoteCheckShipmentConsistencySplitCompleteJobRequest")]
	public class RemoteCheckShipmentConsistencySplitCompleteJobRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.cron.remote.RemoteCheckShipmentConsistencySplitRequest")]
	public class RemoteCheckShipmentConsistencySplitRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteIdConversionStep")]
	public class RemoteIdConversionStep
	{
		[JsonProperty("method")]
		public String Method { get; set; }
		[JsonProperty("map")]
		public String Map { get; set; }
		[JsonProperty("dependsOn")]
		public List<RemoteIdConversionStep> DependsOn { get; set; }
		[JsonProperty("tableAttributes")]
		public List<String> TableAttributes { get; set; }
		[JsonProperty("mapLevelByAttribute")]
		public int MapLevelByAttribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteIdStepTransformation")]
	public class RemoteIdStepTransformation : RemoteTransformation
	{
		[JsonProperty("method")]
		public String Method { get; set; }
		[JsonProperty("idConversionStep")]
		public RemoteIdConversionStep IdConversionStep { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteIdTransformation")]
	public class RemoteIdTransformation : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteIdTransformationNew")]
	public class RemoteIdTransformationNew : RemoteTransformation
	{
		[JsonProperty("method")]
		public String Method { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteIgnoredAttribute")]
	public class RemoteIgnoredAttribute
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("shipmentMetadata")]
		public long? ShipmentMetadata { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteImportDataTrans")]
	public class RemoteImportDataTrans : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteInteractiveDeliveryFormat")]
	public class RemoteInteractiveDeliveryFormat : RemoteDeliveryFormat
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteInternalNavigatorNode")]
	public class RemoteInternalNavigatorNode : RemoteNavigatorNode
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteInternalStorageNavigatorNode")]
	public class RemoteInternalStorageNavigatorNode : RemoteBookmarkNavigatorNode
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteITransRenameMapping")]
	public abstract class RemoteITransRenameMapping
	{
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteJobParameter")]
	public abstract class RemoteJobParameter
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.cron.remote.RemoteJobStructureConsistencyCheckRequest")]
	public class RemoteJobStructureConsistencyCheckRequest : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteListJobParameterValues")]
	public class RemoteListJobParameterValues : RemoteRequest
	{
		[JsonProperty("parameter")]
		public long? Parameter { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteListJobParameterValuesResponse")]
	public class RemoteListJobParameterValuesResponse : RemoteResponse
	{
		[JsonProperty("values")]
		public HashSet<String> Values { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteLoadDataModelDataRequest")]
	public class RemoteLoadDataModelDataRequest : RemoteRequest
	{
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("dataModels")]
		public List<long?> DataModels { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.exchangerate.remote.RemoteLoadExchangeRateDataRequest")]
	public class RemoteLoadExchangeRateDataRequest : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteMaintenanceRequest")]
	public class RemoteMaintenanceRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteManipulateNavigatorNode")]
	public abstract class RemoteManipulateNavigatorNode : RemoteRequest
	{
		[JsonProperty("node")]
		public RemoteNavigatorNode Node { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteManipulateNavigatorNodeResponse")]
	public abstract class RemoteManipulateNavigatorNodeResponse : RemoteResponse
	{
		[JsonProperty("node")]
		public long? Node { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.descriptor.remote.RemoteMassDescriptor")]
	public class RemoteMassDescriptor
	{
		[JsonProperty("entries")]
		public HashSet<RemoteMassEntry> Entries { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.common.remote.RemoteMassEntry")]
	public class RemoteMassEntry
	{
		[JsonProperty("value")]
		public HashSet<String> Value { get; set; }
		[JsonProperty("key")]
		public String Key { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteMergeDimensionNodes")]
	public class RemoteMergeDimensionNodes : RemoteRequest
	{
		[JsonProperty("nodeToDelete")]
		public RemoteDimensionNode NodeToDelete { get; set; }
		[JsonProperty("nodeToMergeTo")]
		public RemoteDimensionNode NodeToMergeTo { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteMergeRowToColumnSplitTransformation")]
	public class RemoteMergeRowToColumnSplitTransformation : RemoteTransformation
	{
		[JsonProperty("transformationChainList")]
		public List<RemoteTransformationChain> TransformationChainList { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteModelEntrySheetDefinition")]
	public class RemoteModelEntrySheetDefinition : RemoteEntrySheetDefinition
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteModelEntrySheetDefinitionNavigatorNode")]
	public class RemoteModelEntrySheetDefinitionNavigatorNode : RemoteUserDefinitionNavigatorNode
	{
		[JsonProperty("definition")]
		public RemoteModelEntrySheetDefinition Definition { get; set; }
		[JsonProperty("metadata")]
		public long? Metadata { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteModelFigureBundle")]
	public class RemoteModelFigureBundle
	{
		[JsonProperty("value")]
		public Double Value { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("modelFigure")]
		public String ModelFigure { get; set; }
		[JsonProperty("shipmentFigure")]
		public String ShipmentFigure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteMoveTechnologySchemaRequest")]
	public class RemoteMoveTechnologySchemaRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("targetSnapshot")]
		public String TargetSnapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteMsAccessDeliveryFormat")]
	public class RemoteMsAccessDeliveryFormat : RemoteFlatfileDeliveryFormat
	{
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteMultiFigureDerivativePack")]
	public class RemoteMultiFigureDerivativePack
	{
		[JsonProperty("subpacks")]
		public HashSet<RemoteSingleFigureDerivativePack> Subpacks { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.welcomescreen.remote.RemoteMyFerdaFolder")]
	public class RemoteMyFerdaFolder : RemoteFolder
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteNavigatorNode")]
	public abstract class RemoteNavigatorNode
	{
		[JsonProperty("parent")]
		public long? Parent { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("updatedBy")]
		public String UpdatedBy { get; set; }
		[JsonProperty("updatedOn")]
		public DateTime? UpdatedOn { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteNewFigurePack")]
	public class RemoteNewFigurePack
	{
		[JsonProperty("values")]
		public HashSet<RemoteFigureOperation> Values { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteNodeCheck")]
	public class RemoteNodeCheck : RemoteCombinationCheck
	{
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteOffice")]
	public class RemoteOffice
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public String Id { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.RemoteOperationAxisItem")]
	public class RemoteOperationAxisItem : RemotePivotAxisItem
	{
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteOrder")]
	public class RemoteOrder
	{
		[JsonProperty("key")]
		public String Key { get; set; }
		[JsonProperty("index")]
		public int Index { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteOrderedAttribute")]
	public class RemoteOrderedAttribute
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.organizational.remote.RemoteOrganizationalChart")]
	public class RemoteOrganizationalChart
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("technologies")]
		public HashSet<String> Technologies { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.organizational.remote.RemoteOrganizationalUnit")]
	public class RemoteOrganizationalUnit
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("members")]
		public HashSet<long?> Members { get; set; }
		[JsonProperty("filter")]
		public RemoteQueryFilterGroup Filter { get; set; }
		[JsonProperty("parentUnit")]
		public long? ParentUnit { get; set; }
		[JsonProperty("chart")]
		public long? Chart { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteOutlierCheck")]
	public class RemoteOutlierCheck : RemoteCombinationCheck
	{
		[JsonProperty("attributes")]
		public HashSet<String> Attributes { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.dto.RemoteOutputItem")]
	public abstract class RemoteOutputItem
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemotePercentageConsecutiveCheck")]
	public class RemotePercentageConsecutiveCheck : RemoteConsecutiveCheck
	{
		[JsonProperty("searchFigure")]
		public String SearchFigure { get; set; }
		[JsonProperty("searchValue")]
		public double SearchValue { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.exchangerate.remote.RemotePeriodRate")]
	public class RemotePeriodRate
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("timescale")]
		public long? Timescale { get; set; }
		[JsonProperty("rate")]
		public double Rate { get; set; }
		[JsonProperty("exchangeRate")]
		public long? ExchangeRate { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.RemotePivot")]
	public class RemotePivot
	{
		[JsonProperty("trendLines")]
		public HashSet<RemoteTimeSerie> TrendLines { get; set; }
		[JsonProperty("rootCell")]
		public RemoteAggregatePivotCell RootCell { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemotePivotAttributeField")]
	public class RemotePivotAttributeField : RemotePivotField
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.RemotePivotAxisItem")]
	public abstract class RemotePivotAxisItem
	{
		[JsonProperty("order")]
		public int Order { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemotePivotCalculatedField")]
	public class RemotePivotCalculatedField : RemotePivotField
	{
		[JsonProperty("formula")]
		public String Formula { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.RemotePivotCellGroup")]
	public class RemotePivotCellGroup
	{
		[JsonProperty("descriptor")]
		public RemoteDescriptor Descriptor { get; set; }
		[JsonProperty("children")]
		public HashSet<RemotePivotCellGroup> Children { get; set; }
		[JsonProperty("aggregates")]
		public HashSet<RemoteBasePivotCell> Aggregates { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.api.RemotePivotDataExport")]
	public class RemotePivotDataExport : RemoteDataExport
	{
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.RemotePivotDef")]
	public class RemotePivotDef
	{
		[JsonProperty("source")]
		public RemoteList Source { get; set; }
		[JsonProperty("rows")]
		public HashSet<RemotePivotAxisItem> Rows { get; set; }
		[JsonProperty("figureMapping")]
		public RemoteList FigureMapping { get; set; }
		[JsonProperty("columns")]
		public HashSet<RemotePivotAxisItem> Columns { get; set; }
		[JsonProperty("operations")]
		public HashSet<RemotePivotOperationDef> Operations { get; set; }
		[JsonProperty("currencies")]
		public HashSet<String> Currencies { get; set; }
		[JsonProperty("attributeMapping")]
		public RemoteList AttributeMapping { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemotePivotDefinition")]
	public class RemotePivotDefinition
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("format")]
		public long? Format { get; set; }
		[JsonProperty("values")]
		public HashSet<RemotePivotValueField> Values { get; set; }
		[JsonProperty("filters")]
		public HashSet<RemotePivotFilterField> Filters { get; set; }
		[JsonProperty("rows")]
		public HashSet<RemotePivotField> Rows { get; set; }
		[JsonProperty("placeholder")]
		public long? Placeholder { get; set; }
		[JsonProperty("queryFilter")]
		public RemoteCriteriaFilter QueryFilter { get; set; }
		[JsonProperty("columns")]
		public HashSet<RemotePivotField> Columns { get; set; }
		[JsonProperty("startPeriod")]
		public long? StartPeriod { get; set; }
		[JsonProperty("additionalFields")]
		public HashSet<RemotePivotField> AdditionalFields { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemotePivotDeliveryFormat")]
	public abstract class RemotePivotDeliveryFormat : RemoteDeliveryFormat
	{
		[JsonProperty("pivotDefinitions")]
		public HashSet<long?> PivotDefinitions { get; set; }
		[JsonProperty("outputFileName")]
		public String OutputFileName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemotePivotDeliveryFormat2003")]
	public class RemotePivotDeliveryFormat2003 : RemotePivotDeliveryFormat
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemotePivotDeliveryFormat2007")]
	public class RemotePivotDeliveryFormat2007 : RemotePivotDeliveryFormat
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemotePivotField")]
	public abstract class RemotePivotField
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemotePivotFilterField")]
	public class RemotePivotFilterField : RemotePivotAttributeField
	{
		[JsonProperty("filterValues")]
		public HashSet<String> FilterValues { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemotePivotChangeOperation")]
	public abstract class RemotePivotChangeOperation : RemotePivotOperation
	{
		[JsonProperty("changeType")]
		public String ChangeType { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemotePivotChangeOperationDef")]
	public abstract class RemotePivotChangeOperationDef : RemotePivotOperationDef
	{
		[JsonProperty("changeType")]
		public String ChangeType { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemotePivotOperation")]
	public abstract class RemotePivotOperation
	{
		[JsonProperty("value")]
		public double Value { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("direction")]
		public String Direction { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemotePivotOperationDef")]
	public abstract class RemotePivotOperationDef
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("direction")]
		public String Direction { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemotePivotValueField")]
	public class RemotePivotValueField : RemotePivotField
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("denominator")]
		public String Denominator { get; set; }
		[JsonProperty("currency")]
		public String Currency { get; set; }
		[JsonProperty("aggregation")]
		public String Aggregation { get; set; }
		[JsonProperty("formula")]
		public String Formula { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemotePlaceholder")]
	public class RemotePlaceholder
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("cellAddress")]
		public String CellAddress { get; set; }
		[JsonProperty("sheetName")]
		public String SheetName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.transformer.RemotePlainObject")]
	public class RemotePlainObject : RemoteTransformerObject
	{
		[JsonProperty("keys")]
		public String[] Keys { get; set; }
		[JsonProperty("values")]
		public RemoteList Values { get; set; }
	}

    [RemoteName("com.idc_cema.ferda.welcomescreen.remote.RemoteList")]
    public class RemoteList
    {
    }

    [RemoteName("com.idc_cema.ferda.crud.remote.transformer.RemotePlainObjectTransformer")]
	public class RemotePlainObjectTransformer : RemoteTransformer
	{
		[JsonProperty("keys")]
		public List<String> Keys { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemotePrepareFlatfileData")]
	public class RemotePrepareFlatfileData : RemoteRequest
	{
		[JsonProperty("query")]
		public RemoteQuery Query { get; set; }
		[JsonProperty("targetTable")]
		public long? TargetTable { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemotePrepareSqlFlatfileDataRequest")]
	public class RemotePrepareSqlFlatfileDataRequest : RemoteRequest
	{
		[JsonProperty("sqlQuery")]
		public String SqlQuery { get; set; }
		[JsonProperty("targetTable")]
		public long? TargetTable { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemotePriceBandForecastCalcNavigatorNode")]
	public class RemotePriceBandForecastCalcNavigatorNode : RemoteInternalNavigatorNode
	{
		[JsonProperty("configuration")]
		public long? Configuration { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.forecasting.remote.priceband.api.RemotePriceBandForecastCalculationInnerRequest")]
	public class RemotePriceBandForecastCalculationInnerRequest : RemotePriceBandForecastCalculationRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.forecasting.remote.priceband.api.RemotePriceBandForecastCalculationRequest")]
	public class RemotePriceBandForecastCalculationRequest : RemoteRequest
	{
		[JsonProperty("forecastCalculationConfiguration")]
		public long? ForecastCalculationConfiguration { get; set; }
		[JsonProperty("massDescriptor")]
		public RemoteMassDescriptor MassDescriptor { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteProcedureJob")]
	public class RemoteProcedureJob
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("type")]
		public String Type { get; set; }
		[JsonProperty("parameters")]
		public HashSet<RemoteJobParameter> Parameters { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("procedureName")]
		public String ProcedureName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.schedule.remote.RemoteProduct")]
	public class RemoteProduct
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("shortName")]
		public String ShortName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dashboard.remote.RemoteQCDashboard")]
	public class RemoteQCDashboard : RemoteDashboard
	{
		[JsonProperty("checks")]
		public HashSet<long?> Checks { get; set; }
		[JsonProperty("deadline")]
		public DateTime? Deadline { get; set; }
		[JsonProperty("maxDays")]
		public int MaxDays { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dashboard.remote.RemoteQCDashboardItemReloadRequest")]
	public class RemoteQCDashboardItemReloadRequest : RemoteDashboardReloadRequest
	{
		[JsonProperty("check")]
		public long? Check { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dashboard.remote.RemoteQCDashboardOutputItem")]
	public class RemoteQCDashboardOutputItem : RemoteDashboardOutputItem
	{
		[JsonProperty("checked")]
		public DateTime? Checked { get; set; }
		[JsonProperty("check")]
		public long? Check { get; set; }
		[JsonProperty("errorCount")]
		public int? ErrorCount { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.query.RemoteQMapping")]
	public abstract class RemoteQMapping
	{
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.query.RemoteQMappingAttribute")]
	public class RemoteQMappingAttribute : RemoteQMapping
	{
		[JsonProperty("what")]
		public String What { get; set; }
		[JsonProperty("to")]
		public String To { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.query.RemoteQMappingAttributeCons")]
	public class RemoteQMappingAttributeCons : RemoteQMapping
	{
		[JsonProperty("what")]
		public String What { get; set; }
		[JsonProperty("to")]
		public String To { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.query.RemoteQMappingFigure")]
	public class RemoteQMappingFigure : RemoteQMapping
	{
		[JsonProperty("what")]
		public String What { get; set; }
		[JsonProperty("to")]
		public String To { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.query.RemoteQMappingFigureCons")]
	public class RemoteQMappingFigureCons : RemoteQMapping
	{
		[JsonProperty("what")]
		public Double What { get; set; }
		[JsonProperty("to")]
		public String To { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qt.remote.domain.RemoteQTMessageStatus")]
	public class RemoteQTMessageStatus
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("type")]
		public String Type { get; set; }
		[JsonProperty("resultMessage")]
		public String ResultMessage { get; set; }
		[JsonProperty("createdOn")]
		public DateTime? CreatedOn { get; set; }
		[JsonProperty("confirmedOn")]
		public DateTime? ConfirmedOn { get; set; }
		[JsonProperty("success")]
		public bool Success { get; set; }
		[JsonProperty("user")]
		public String User { get; set; }
		[JsonProperty("scheduledJob")]
		public String ScheduledJob { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qt.remote.api.RemoteQTPublish")]
	public abstract class RemoteQTPublish : RemoteRequest
	{
		[JsonProperty("publishBatchId")]
		public long? PublishBatchId { get; set; }
		[JsonProperty("user")]
		public String User { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qt.remote.api.RemoteQTPublishExchangeRate")]
	public class RemoteQTPublishExchangeRate : RemoteQTPublish
	{
	}

	[RemoteName("com.idc_cema.ferda.qt.remote.api.RemoteQTPublishProfile")]
	public class RemoteQTPublishProfile : RemoteQTPublish
	{
		[JsonProperty("deliverables")]
		public List<long?> Deliverables { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteQuery")]
	public class RemoteQuery : RemoteRequest
	{
		[JsonProperty("selectAtr")]
		public HashSet<String> SelectAtr { get; set; }
		[JsonProperty("versions")]
		public HashSet<String> Versions { get; set; }
		[JsonProperty("filterGroup")]
		public RemoteQueryFilterGroup FilterGroup { get; set; }
		[JsonProperty("technologies")]
		public HashSet<String> Technologies { get; set; }
		[JsonProperty("figures")]
		public HashSet<String> Figures { get; set; }
		[JsonProperty("output")]
		public String Output { get; set; }
		[JsonProperty("currencyVersion")]
		public HashSet<long?> CurrencyVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteQueryFilter")]
	public abstract class RemoteQueryFilter
	{
		[JsonProperty("operator")]
		public String Operator { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteQueryFilterGroup")]
	public class RemoteQueryFilterGroup
	{
		[JsonProperty("operator")]
		public String Operator { get; set; }
		[JsonProperty("filters")]
		public HashSet<RemoteQueryFilter> Filters { get; set; }
		[JsonProperty("filterGroups")]
		public HashSet<RemoteQueryFilterGroup> FilterGroups { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteQueryResponse")]
	public class RemoteQueryResponse : RemoteResponse
	{
		[JsonProperty("figureRecords")]
		public HashSet<RemoteFigureRecord> FigureRecords { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteQueryToolAccessToViewsDeliveryFormat")]
	public class RemoteQueryToolAccessToViewsDeliveryFormat : RemoteDeliveryFormat
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteQueryToolDeliveryFormat")]
	public class RemoteQueryToolDeliveryFormat : RemoteFlatfileDeliveryFormat
	{
		[JsonProperty("orders")]
		public HashSet<RemoteFieldOrder> Orders { get; set; }
		[JsonProperty("market")]
		public String Market { get; set; }
		[JsonProperty("qtDataSetId")]
		public long? QtDataSetId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteRankingChangePivotOperation")]
	public class RemoteRankingChangePivotOperation : RemotePivotChangeOperation
	{
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteRankingChangePivotOperationDef")]
	public class RemoteRankingChangePivotOperationDef : RemotePivotChangeOperationDef
	{
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteRankingPivotOperation")]
	public class RemoteRankingPivotOperation : RemotePivotOperation
	{
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteRankingPivotOperationDef")]
	public class RemoteRankingPivotOperationDef : RemotePivotOperationDef
	{
	}

	[RemoteName("com.idc_cema.ferda.clientcache.remote.RemoteRebuildCacheRequest")]
	public class RemoteRebuildCacheRequest : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.cron.remote.RemoteRefreshSnapshotsStateRequest")]
	public class RemoteRefreshSnapshotsStateRequest : RemoteRequest
	{
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.comment.remote.RemoteReIndexComment")]
	public class RemoteReIndexComment : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteReloadAttributeValueRequest")]
	public class RemoteReloadAttributeValueRequest : RemoteRequest
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteReloadDimensionMap")]
	public class RemoteReloadDimensionMap : RemoteRequest
	{
		[JsonProperty("mapId")]
		public String MapId { get; set; }
		[JsonProperty("dimId")]
		public long? DimId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.schema.remote.RemoteReloadShipmentUniqueIndexRequest")]
	public class RemoteReloadShipmentUniqueIndexRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteReloadSnapshotStore")]
	public class RemoteReloadSnapshotStore : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteReloadTechnologyAttributes")]
	public class RemoteReloadTechnologyAttributes : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.dimensions.remote.RemoteReloadTechnologyDimensionMap")]
	public class RemoteReloadTechnologyDimensionMap : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("nodes")]
		public List<long?> Nodes { get; set; }
		[JsonProperty("operation")]
		public String Operation { get; set; }
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteRemoveShipmentAttributeRequest")]
	public class RemoteRemoveShipmentAttributeRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("shipmentAttribute")]
		public long? ShipmentAttribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteRenameColumnTrans")]
	public class RemoteRenameColumnTrans : RemoteTransformation
	{
		[JsonProperty("figureMapping")]
		public HashSet<RemoteITransRenameMapping> FigureMapping { get; set; }
		[JsonProperty("attributeMapping")]
		public HashSet<RemoteITransRenameMapping> AttributeMapping { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteRenameColumnTransformation")]
	public class RemoteRenameColumnTransformation : RemoteTransformation
	{
		[JsonProperty("renameMapping")]
		public HashSet<RemoteTransformationRenameMapping> RenameMapping { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteReportNavigatorNode")]
	public class RemoteReportNavigatorNode : RemoteNavigatorNode
	{
		[JsonProperty("report")]
		public RemoteProcedureJob Report { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.api.remote.RemoteRequest")]
	public abstract class RemoteRequest
	{
		[JsonProperty("id")]
		public String Id { get; set; }
		[JsonProperty("priority")]
		public int Priority { get; set; }
		[JsonProperty("authKey")]
		public String AuthKey { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.common.remote.RemoteRequestFailedResponse")]
	public class RemoteRequestFailedResponse : RemoteResponse
	{
		[JsonProperty("failureDate")]
		public DateTime? FailureDate { get; set; }
		[JsonProperty("failureMessage")]
		public String FailureMessage { get; set; }
		[JsonProperty("exceptionIdentifier")]
		public String ExceptionIdentifier { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.common.remote.RemoteRequestSucceededResponse")]
	public class RemoteRequestSucceededResponse : RemoteResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteResetFailedDatachanges")]
	public class RemoteResetFailedDatachanges : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.api.remote.RemoteResponse")]
	public abstract class RemoteResponse
	{
		[JsonProperty("requestId")]
		public String RequestId { get; set; }
		[JsonProperty("processingTime")]
		public long ProcessingTime { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteRestoreDataModelRequest")]
	public class RemoteRestoreDataModelRequest : RemoteRequest
	{
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("dataModel")]
		public long? DataModel { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteRight")]
	public abstract class RemoteRight
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("user")]
		public String User { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteRole")]
	public abstract class RemoteRole
	{
		[JsonProperty("id")]
		public String Id { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteRoleGroup")]
	public abstract class RemoteRoleGroup
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteRowToColumnTransformation")]
	public class RemoteRowToColumnTransformation : RemoteTransformation
	{
		[JsonProperty("figures")]
		public HashSet<String> Figures { get; set; }
		[JsonProperty("columnName")]
		public String ColumnName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.rule.remote.RemoteRule")]
	public abstract class RemoteRule
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.client.RemoteSaveClientDeliveryClientRequest")]
	public class RemoteSaveClientDeliveryClientRequest : RemoteRequest
	{
		[JsonProperty("client")]
		public RemoteClientDeliveryClient Client { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.configuration.RemoteSaveClientDeliveryConfigurationRequest")]
	public class RemoteSaveClientDeliveryConfigurationRequest : RemoteRequest
	{
		[JsonProperty("configuration")]
		public RemoteClientDeliveryConfiguration Configuration { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteSaveClientDeliveryFailedResult")]
	public class RemoteSaveClientDeliveryFailedResult : RemoteRequest
	{
		[JsonProperty("failedMessage")]
		public String FailedMessage { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteSaveClientDeliveryObjectResponse")]
	public class RemoteSaveClientDeliveryObjectResponse : RemoteResponse
	{
		[JsonProperty("objectInQuestionId")]
		public long? ObjectInQuestionId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.profile.RemoteSaveClientDeliveryProfileRequest")]
	public class RemoteSaveClientDeliveryProfileRequest : RemoteRequest
	{
		[JsonProperty("profile")]
		public RemoteClientDeliveryClientProfile Profile { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.report.RemoteSaveClientDeliveryReportRequest")]
	public class RemoteSaveClientDeliveryReportRequest : RemoteRequest
	{
		[JsonProperty("report")]
		public RemoteClientDeliveryReport Report { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteSaveClientDeliveryResult")]
	public class RemoteSaveClientDeliveryResult : RemoteRequest
	{
		[JsonProperty("filenames")]
		public List<String> Filenames { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.RemoteSaveContractRequest")]
	public class RemoteSaveContractRequest : RemoteRequest
	{
		[JsonProperty("contract")]
		public RemoteContract Contract { get; set; }
		[JsonProperty("groupToFileMapping")]
		public HashSet<RemoteGroupFileMapping> GroupToFileMapping { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteSaveDataExportPivotFailedResult")]
	public class RemoteSaveDataExportPivotFailedResult : RemoteSaveClientDeliveryFailedResult
	{
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteSaveDataExportPivotResult")]
	public class RemoteSaveDataExportPivotResult : RemoteSaveClientDeliveryResult
	{
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteSaveDataModelDataRequest")]
	public class RemoteSaveDataModelDataRequest : RemoteRequest
	{
		[JsonProperty("file")]
		public long? File { get; set; }
		[JsonProperty("dataModels")]
		public List<long?> DataModels { get; set; }
		[JsonProperty("updateEntities")]
		public bool UpdateEntities { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.model.remote.RemoteSaveDataModelIncompleteResponse")]
	public class RemoteSaveDataModelIncompleteResponse : RemoteFileResponse
	{
		[JsonProperty("message")]
		public String Message { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.exchangerate.remote.RemoteSaveExchangeRateDataRequest")]
	public class RemoteSaveExchangeRateDataRequest : RemoteRequest
	{
		[JsonProperty("file")]
		public long? File { get; set; }
		[JsonProperty("exchangeRate")]
		public long? ExchangeRate { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteSaveNavigatorNode")]
	public class RemoteSaveNavigatorNode : RemoteManipulateNavigatorNode
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteSaveNavigatorNodeResponse")]
	public class RemoteSaveNavigatorNodeResponse : RemoteManipulateNavigatorNodeResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteSaveOrUpdateIdRequest")]
	public class RemoteSaveOrUpdateIdRequest : RemoteRequest
	{
		[JsonProperty("payload")]
		public Object Payload { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.response.RemoteSaveOrUpdateIdResponse")]
	public class RemoteSaveOrUpdateIdResponse : RemoteResponse
	{
		[JsonProperty("payloadId")]
		public Object PayloadId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteSaveOrUpdateRequest")]
	public class RemoteSaveOrUpdateRequest : RemoteRequest
	{
		[JsonProperty("payload")]
		public Object Payload { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.response.RemoteSaveOrUpdateResponse")]
	public class RemoteSaveOrUpdateResponse : RemoteResponse
	{
		[JsonProperty("payload")]
		public Object Payload { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteServer")]
	public class RemoteServer
	{
		[JsonProperty("port")]
		public int? Port { get; set; }
		[JsonProperty("serverId")]
		public String ServerId { get; set; }
		[JsonProperty("serverName")]
		public String ServerName { get; set; }
		[JsonProperty("hostname")]
		public String Hostname { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteSetScheduledJobTopPriorityRequest")]
	public class RemoteSetScheduledJobTopPriorityRequest : RemoteRequest
	{
		[JsonProperty("scheduledJob")]
		public String ScheduledJob { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteShareCheck")]
	public class RemoteShareCheck : RemoteCombinationCheck
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("shareBy")]
		public String ShareBy { get; set; }
		[JsonProperty("minimumShare")]
		public double MinimumShare { get; set; }
		[JsonProperty("maximumShare")]
		public double MaximumShare { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteSharePivotOperation")]
	public class RemoteSharePivotOperation : RemotePivotOperation
	{
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteSharePivotOperationDef")]
	public class RemoteSharePivotOperationDef : RemotePivotOperationDef
	{
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteShipment")]
	public class RemoteShipment
	{
		[JsonProperty("descriptor")]
		public RemoteDimensionDescriptor Descriptor { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("figures")]
		public HashSet<RemoteFigureDefinition> Figures { get; set; }
		[JsonProperty("splits")]
		public HashSet<RemoteSplit> Splits { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteShipmentAttribute")]
	public class RemoteShipmentAttribute
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("shipmentMetadata")]
		public long? ShipmentMetadata { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteShipmentCopy")]
	public class RemoteShipmentCopy : RemoteRequest
	{
		[JsonProperty("descriptor")]
		public RemoteMassDescriptor Descriptor { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("targetDescriptor")]
		public RemoteDescriptor TargetDescriptor { get; set; }
		[JsonProperty("dataVersion")]
		public String DataVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteShipmentCriteriaQueryRequest")]
	public class RemoteShipmentCriteriaQueryRequest : RemoteCriteriaQueryRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteShipmentDelete")]
	public class RemoteShipmentDelete : RemoteRequest
	{
		[JsonProperty("descriptor")]
		public RemoteMassDescriptor Descriptor { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("dataVersion")]
		public String DataVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteShipmentExport")]
	public class RemoteShipmentExport : RemoteRequest
	{
		[JsonProperty("definition")]
		public RemoteShipmentExportDefinition Definition { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteShipmentExportAttributeOutputItem")]
	public class RemoteShipmentExportAttributeOutputItem : RemoteShipmentExportOutputItem
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteShipmentExportDefinition")]
	public class RemoteShipmentExportDefinition
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("headers")]
		public RemoteList Headers { get; set; }
		[JsonProperty("format")]
		public String Format { get; set; }
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("borderColor")]
		public String BorderColor { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("sheetByAttribute")]
		public String SheetByAttribute { get; set; }
		[JsonProperty("orderByAttributes")]
		public HashSet<RemoteShipmentExportAttributeOutputItem> OrderByAttributes { get; set; }
		[JsonProperty("items")]
		public HashSet<RemoteShipmentExportOutputItem> Items { get; set; }
		[JsonProperty("exchangeRate")]
		public long? ExchangeRate { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteShipmentExportFigureOutputItem")]
	public class RemoteShipmentExportFigureOutputItem : RemoteShipmentExportOutputItem
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteShipmentExportOutputItem")]
	public class RemoteShipmentExportOutputItem
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteShipmentExportResponse")]
	public class RemoteShipmentExportResponse : RemoteFileResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteShipmentExportSplitContainer")]
	public class RemoteShipmentExportSplitContainer : RemoteShipmentExportOutputItem
	{
		[JsonProperty("attributes")]
		public HashSet<RemoteShipmentExportAttributeOutputItem> Attributes { get; set; }
		[JsonProperty("splitMetadata")]
		public long? SplitMetadata { get; set; }
		[JsonProperty("items")]
		public HashSet<RemoteShipmentExportSplitOutputItem> Items { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteShipmentExportSplitOutputItem")]
	public class RemoteShipmentExportSplitOutputItem : RemoteShipmentExportOutputItem
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("dimension")]
		public long? Dimension { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteShipmentFigure")]
	public class RemoteShipmentFigure
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("figureToChange")]
		public String FigureToChange { get; set; }
		[JsonProperty("aggregationFormula")]
		public String AggregationFormula { get; set; }
		[JsonProperty("aggregationPrefix")]
		public String AggregationPrefix { get; set; }
		[JsonProperty("aggregationSuffix")]
		public String AggregationSuffix { get; set; }
		[JsonProperty("exchangeRateFigureType")]
		public String ExchangeRateFigureType { get; set; }
		[JsonProperty("updateOrder")]
		public int UpdateOrder { get; set; }
		[JsonProperty("dbField")]
		public String DbField { get; set; }
		[JsonProperty("formulaGet")]
		public long? FormulaGet { get; set; }
		[JsonProperty("formulas")]
		public List<long?> Formulas { get; set; }
		[JsonProperty("columnName")]
		public String ColumnName { get; set; }
		[JsonProperty("figureToSet")]
		public String FigureToSet { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteShipmentChange")]
	public class RemoteShipmentChange : RemoteRequest
	{
		[JsonProperty("descriptor")]
		public RemoteDescriptor Descriptor { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("newAttributeValue")]
		public String NewAttributeValue { get; set; }
		[JsonProperty("dataVersion")]
		public String DataVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteShipmentCheck")]
	public class RemoteShipmentCheck : RemoteCombinationCheck
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteShipmentIdColumn")]
	public class RemoteShipmentIdColumn : RemoteAttributeColumn
	{
		[JsonProperty("sequenceDefinition")]
		public String SequenceDefinition { get; set; }
		[JsonProperty("defaultDefinition")]
		public String DefaultDefinition { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.shipmentimport.RemoteShipmentImport")]
	public class RemoteShipmentImport : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("shipment")]
		public RemoteFigureRecord Shipment { get; set; }
		[JsonProperty("dataVersion")]
		public String DataVersion { get; set; }
		[JsonProperty("splits")]
		public HashSet<RemoteFigureRecord> Splits { get; set; }
		[JsonProperty("currencyVersion")]
		public long? CurrencyVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.shipmentimport.RemoteShipmentImportResponse")]
	public class RemoteShipmentImportResponse : RemoteResponse
	{
		[JsonProperty("shipmentId")]
		public long ShipmentId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteShipmentMerge")]
	public class RemoteShipmentMerge : RemoteRequest
	{
		[JsonProperty("descriptor")]
		public RemoteMassDescriptor Descriptor { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("targetDatabase")]
		public String TargetDatabase { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteShipmentMetadata")]
	public abstract class RemoteShipmentMetadata
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("modelDimensionMap")]
		public String ModelDimensionMap { get; set; }
		[JsonProperty("modelAttribute")]
		public String ModelAttribute { get; set; }
		[JsonProperty("shipmentDimensions")]
		public HashSet<String> ShipmentDimensions { get; set; }
		[JsonProperty("shipmentAttributes")]
		public HashSet<RemoteShipmentAttribute> ShipmentAttributes { get; set; }
		[JsonProperty("currentTimescale")]
		public long? CurrentTimescale { get; set; }
		[JsonProperty("geographicalMap")]
		public String GeographicalMap { get; set; }
		[JsonProperty("partitionAttribute")]
		public String PartitionAttribute { get; set; }
		[JsonProperty("allowedAttributes")]
		public HashSet<String> AllowedAttributes { get; set; }
		[JsonProperty("shipmentId")]
		public String ShipmentId { get; set; }
		[JsonProperty("splits")]
		public HashSet<RemoteSplitMetadata> Splits { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteShipmentMetadataCompile")]
	public class RemoteShipmentMetadataCompile : RemoteShipmentMetadata
	{
		[JsonProperty("figureMetadata")]
		public HashSet<RemoteShipmentFigure> FigureMetadata { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteShipmentMetadataMvel")]
	public class RemoteShipmentMetadataMvel : RemoteShipmentMetadata
	{
		[JsonProperty("technologyFormulas")]
		public HashSet<RemoteTechnologyFormula> TechnologyFormulas { get; set; }
		[JsonProperty("technologyFigures")]
		public HashSet<RemoteTechnologyFigure> TechnologyFigures { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteShipmentRestore")]
	public class RemoteShipmentRestore : RemoteRequest
	{
		[JsonProperty("descriptor")]
		public RemoteMassDescriptor Descriptor { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("sourceDataVersion")]
		public String SourceDataVersion { get; set; }
		[JsonProperty("targetDataVersion")]
		public String TargetDataVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteShipmentTmpAndSplitImportTransformation")]
	public class RemoteShipmentTmpAndSplitImportTransformation : RemoteTransformation
	{
		[JsonProperty("filterGroup")]
		public RemoteQueryFilterGroup FilterGroup { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.schedule.remote.RemoteSchedule")]
	public class RemoteSchedule
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("dates")]
		public HashSet<RemoteScheduleDate> Dates { get; set; }
		[JsonProperty("technologies")]
		public HashSet<String> Technologies { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.schedule.remote.RemoteScheduleDate")]
	public class RemoteScheduleDate
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("date")]
		public DateTime? Date { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("schedule")]
		public long? Schedule { get; set; }
		[JsonProperty("category")]
		public long? Category { get; set; }
		[JsonProperty("product")]
		public long? Product { get; set; }
		[JsonProperty("geography")]
		public long? Geography { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.job.remote.RemoteScheduledJob")]
	public class RemoteScheduledJob
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("parent")]
		public String Parent { get; set; }
		[JsonProperty("state")]
		public String State { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("scheduled")]
		public DateTime? Scheduled { get; set; }
		[JsonProperty("finished")]
		public DateTime? Finished { get; set; }
		[JsonProperty("request")]
		public RemoteRequest Request { get; set; }
		[JsonProperty("progress")]
		public double Progress { get; set; }
		[JsonProperty("response")]
		public RemoteResponse Response { get; set; }
		[JsonProperty("fileSize")]
		public long? FileSize { get; set; }
		[JsonProperty("requestClass")]
		public String RequestClass { get; set; }
		[JsonProperty("requestId")]
		public String RequestId { get; set; }
		[JsonProperty("username")]
		public String Username { get; set; }
		[JsonProperty("executionPriority")]
		public int? ExecutionPriority { get; set; }
		[JsonProperty("topPrioritySet")]
		public DateTime? TopPrioritySet { get; set; }
		[JsonProperty("started")]
		public DateTime? Started { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteSimpleAttribute")]
	public class RemoteSimpleAttribute : RemoteAttribute
	{
		[JsonProperty("values")]
		public HashSet<String> Values { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.query.criteria.RemoteSimpleKey")]
	public class RemoteSimpleKey : RemoteCriteriaKey
	{
		[JsonProperty("key")]
		public String Key { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteSimpleQueryFilter")]
	public class RemoteSimpleQueryFilter : RemoteQueryFilter
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("filter")]
		public HashSet<String> Filter { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteSingleFigureDerivativePack")]
	public class RemoteSingleFigureDerivativePack
	{
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("derivatives")]
		public HashSet<RemoteFigureDerivative> Derivatives { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteSnapshot")]
	public class RemoteSnapshot
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public String Id { get; set; }
		[JsonProperty("state")]
		public String State { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("technologies")]
		public HashSet<String> Technologies { get; set; }
		[JsonProperty("createdBy")]
		public String CreatedBy { get; set; }
		[JsonProperty("jobId")]
		public String JobId { get; set; }
		[JsonProperty("started")]
		public DateTime? Started { get; set; }
		[JsonProperty("created")]
		public DateTime? Created { get; set; }
		[JsonProperty("deployStarted")]
		public DateTime? DeployStarted { get; set; }
		[JsonProperty("deployed")]
		public DateTime? Deployed { get; set; }
		[JsonProperty("deployedBy")]
		public String DeployedBy { get; set; }
		[JsonProperty("deployedSize")]
		public long? DeployedSize { get; set; }
		[JsonProperty("stage")]
		public String Stage { get; set; }
		[JsonProperty("geography")]
		public long? Geography { get; set; }
		[JsonProperty("snapshotSize")]
		public long? SnapshotSize { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteSnapshotTechnologyLink")]
	public class RemoteSnapshotTechnologyLink
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("technologyVersion")]
		public long? TechnologyVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.account.remote.RemoteSource")]
	public class RemoteSource
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public int? Id { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.rule.remote.RemoteSpecification")]
	public abstract class RemoteSpecification : RemoteRule
	{
		[JsonProperty("area")]
		public RemoteQueryFilterGroup Area { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteSpecifiedCountRequest")]
	public class RemoteSpecifiedCountRequest : RemoteCountRequest
	{
		[JsonProperty("masterClass")]
		public String MasterClass { get; set; }
		[JsonProperty("masterId")]
		public Object MasterId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteSpecifiedCriteriaQueryRequest")]
	public class RemoteSpecifiedCriteriaQueryRequest : RemoteCriteriaQueryRequest
	{
		[JsonProperty("masterClass")]
		public String MasterClass { get; set; }
		[JsonProperty("masterId")]
		public Object MasterId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteSpecifiedDeleteRequest")]
	public class RemoteSpecifiedDeleteRequest : RemoteDeleteRequest
	{
		[JsonProperty("masterClass")]
		public String MasterClass { get; set; }
		[JsonProperty("masterId")]
		public Object MasterId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteSpecifiedGetRequest")]
	public class RemoteSpecifiedGetRequest : RemoteGetRequest
	{
		[JsonProperty("masterClass")]
		public String MasterClass { get; set; }
		[JsonProperty("masterId")]
		public Object MasterId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.request.RemoteSpecifiedSaveOrUpdateRequest")]
	public class RemoteSpecifiedSaveOrUpdateRequest : RemoteSaveOrUpdateRequest
	{
		[JsonProperty("masterClass")]
		public String MasterClass { get; set; }
		[JsonProperty("masterId")]
		public Object MasterId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteSplit")]
	public class RemoteSplit
	{
		[JsonProperty("definition")]
		public HashSet<RemoteSplitDefinition> Definition { get; set; }
		[JsonProperty("splitMetadata")]
		public long? SplitMetadata { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteSplitCleanUp")]
	public class RemoteSplitCleanUp : RemoteCleanUpRequest
	{
		[JsonProperty("splitMetadata")]
		public long? SplitMetadata { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteSplitDefinition")]
	public class RemoteSplitDefinition
	{
		[JsonProperty("node")]
		public long? Node { get; set; }
		[JsonProperty("figures")]
		public HashSet<RemoteSplitFigureDefinition> Figures { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteSplitEntry")]
	public class RemoteSplitEntry
	{
		[JsonProperty("descriptor")]
		public RemoteDescriptor Descriptor { get; set; }
		[JsonProperty("figurePack")]
		public RemoteFigurePack FigurePack { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteSplitFigure")]
	public class RemoteSplitFigure
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("splitMetadata")]
		public long? SplitMetadata { get; set; }
		[JsonProperty("modifier")]
		public String Modifier { get; set; }
		[JsonProperty("alternativeSplit")]
		public String AlternativeSplit { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteSplitFigureColumn")]
	public class RemoteSplitFigureColumn : RemoteFigureColumn
	{
		[JsonProperty("splitFigure")]
		public RemoteSplitFigure SplitFigure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipmentsnew.remote.RemoteSplitFigureDefinition")]
	public class RemoteSplitFigureDefinition : RemoteFigureDefinition
	{
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteSplitCheck")]
	public class RemoteSplitCheck : RemoteConstraint
	{
		[JsonProperty("map")]
		public String Map { get; set; }
		[JsonProperty("figures")]
		public HashSet<String> Figures { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteSplitMetadata")]
	public class RemoteSplitMetadata
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("shipmentMetadata")]
		public long? ShipmentMetadata { get; set; }
		[JsonProperty("dimensionMap")]
		public String DimensionMap { get; set; }
		[JsonProperty("splitFigures")]
		public HashSet<RemoteSplitFigure> SplitFigures { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteSplitTransTable")]
	public class RemoteSplitTransTable : RemoteTransTable
	{
		[JsonProperty("splitMetadata")]
		public RemoteSplitMetadata SplitMetadata { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteSqlDerivedAttribute")]
	public class RemoteSqlDerivedAttribute : RemoteDerivedAttribute
	{
	}

	[RemoteName("com.idc_cema.ferda.file.remote.domain.RemoteSQLiteFile")]
	public class RemoteSQLiteFile : RemoteTemporaryFile
	{
		[JsonProperty("tables")]
		public List<RemoteSQLiteFileTable> Tables { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.domain.RemoteSQLiteFileHeader")]
	public class RemoteSQLiteFileHeader
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("type")]
		public String Type { get; set; }
		[JsonProperty("path")]
		public String Path { get; set; }
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("numericOperator")]
		public String NumericOperator { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.sqlite.remote.RemoteSQLiteFileResponse")]
	public class RemoteSQLiteFileResponse : RemoteResponse
	{
		[JsonProperty("file")]
		public long? File { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.domain.RemoteSQLiteFileTable")]
	public class RemoteSQLiteFileTable
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("headers")]
		public List<RemoteSQLiteFileHeader> Headers { get; set; }
		[JsonProperty("tableName")]
		public String TableName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteSqlProcedureTransformation")]
	public class RemoteSqlProcedureTransformation : RemoteTransformation
	{
		[JsonProperty("procedureName")]
		public String ProcedureName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.account.remote.RemoteStatus")]
	public class RemoteStatus
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public int? Id { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteStopTransformation")]
	public class RemoteStopTransformation : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteSyncUserWithLDAPRequest")]
	public class RemoteSyncUserWithLDAPRequest : RemoteRequest
	{
		[JsonProperty("userName")]
		public String UserName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteTable")]
	public class RemoteTable
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("schema")]
		public String Schema { get; set; }
		[JsonProperty("alias")]
		public String Alias { get; set; }
		[JsonProperty("columns")]
		public List<RemoteColumn> Columns { get; set; }
		[JsonProperty("databaseName")]
		public String DatabaseName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.organizational.remote.RemoteTeamLead")]
	public class RemoteTeamLead : RemoteTeamMember
	{
	}

	[RemoteName("com.idc_cema.ferda.organizational.remote.RemoteTeamMember")]
	public class RemoteTeamMember
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("user")]
		public String User { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteTechnology")]
	public class RemoteTechnology
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public String Id { get; set; }
		[JsonProperty("type")]
		public String Type { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("formulaType")]
		public String FormulaType { get; set; }
		[JsonProperty("shipmentMetadata")]
		public RemoteShipmentMetadata ShipmentMetadata { get; set; }
		[JsonProperty("status")]
		public String Status { get; set; }
		[JsonProperty("splits")]
		public HashSet<RemoteSplit> Splits { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteTechnologyCleanUp")]
	public class RemoteTechnologyCleanUp : RemoteCleanUpRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteTechnologyFigure")]
	public class RemoteTechnologyFigure
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("shipmentMetadata")]
		public long? ShipmentMetadata { get; set; }
		[JsonProperty("formula")]
		public String Formula { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteTechnologyFormula")]
	public class RemoteTechnologyFormula
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("shipmentMetadata")]
		public long? ShipmentMetadata { get; set; }
		[JsonProperty("event")]
		public String Event { get; set; }
		[JsonProperty("formula")]
		public String Formula { get; set; }
		[JsonProperty("adjustedFigure")]
		public String AdjustedFigure { get; set; }
		[JsonProperty("impactedFigure")]
		public String ImpactedFigure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.welcomescreen.remote.RemoteTechnologyGroup")]
	public class RemoteTechnologyGroup
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
		[JsonProperty("img")]
		public String Img { get; set; }
		[JsonProperty("groupItems")]
		public List<RemoteTechnologyGroupItem> GroupItems { get; set; }
		[JsonProperty("folder")]
		public long? Folder { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.welcomescreen.remote.RemoteTechnologyGroupItem")]
	public class RemoteTechnologyGroupItem
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("group")]
		public long? Group { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteTechnologyMetadata")]
	public class RemoteTechnologyMetadata
	{
		[JsonProperty("attributes")]
		public HashSet<String> Attributes { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("modelMetadata")]
		public HashSet<long?> ModelMetadata { get; set; }
		[JsonProperty("dimensionMaps")]
		public HashSet<String> DimensionMaps { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.api.RemoteTechnologyOutputItems")]
	public class RemoteTechnologyOutputItems
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("outputItems")]
		public RemoteList OutputItems { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteTechnologyRight")]
	public class RemoteTechnologyRight : RemoteRight
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("roleGroups")]
		public HashSet<RemoteTechnologyRoleGroup> RoleGroups { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteTechnologyRole")]
	public class RemoteTechnologyRole : RemoteRole
	{
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteTechnologyRoleGroup")]
	public class RemoteTechnologyRoleGroup : RemoteRoleGroup
	{
		[JsonProperty("roles")]
		public HashSet<RemoteTechnologyRole> Roles { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteTechnologyTopNAttribute")]
	public class RemoteTechnologyTopNAttribute
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("lastUpdatedOn")]
		public DateTime? LastUpdatedOn { get; set; }
		[JsonProperty("topNAttribute")]
		public String TopNAttribute { get; set; }
		[JsonProperty("technologyTopNAttValues")]
		public HashSet<RemoteTechnologyTopNAttributeValue> TechnologyTopNAttValues { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteTechnologyTopNAttributeValue")]
	public class RemoteTechnologyTopNAttributeValue
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("node")]
		public long? Node { get; set; }
		[JsonProperty("order")]
		public int? Order { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteTechTriggerTrans")]
	public class RemoteTechTriggerTrans : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.file.remote.domain.RemoteTemporaryFile")]
	public class RemoteTemporaryFile : RemoteFerdaFile
	{
		[JsonProperty("expirationDate")]
		public DateTime? ExpirationDate { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.cron.remote.RemoteTemporaryFileDeleteRequest")]
	public class RemoteTemporaryFileDeleteRequest : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.RemoteTemporaryTable")]
	public class RemoteTemporaryTable
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("host")]
		public String Host { get; set; }
		[JsonProperty("port")]
		public int Port { get; set; }
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
		[JsonProperty("schemaName")]
		public String SchemaName { get; set; }
		[JsonProperty("tableName")]
		public String TableName { get; set; }
		[JsonProperty("expirationDate")]
		public DateTime? ExpirationDate { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.cron.remote.RemoteTemporaryTableDropRequest")]
	public class RemoteTemporaryTableDropRequest : RemoteRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteTemporaryTableResponse")]
	public class RemoteTemporaryTableResponse : RemoteResponse
	{
		[JsonProperty("table")]
		public RemoteTemporaryTable Table { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.RemoteTimeSerie")]
	public class RemoteTimeSerie
	{
		[JsonProperty("trendLine")]
		public List<RemoteBasePivotCell> TrendLine { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteTimestampUserDefinition")]
	public abstract class RemoteTimestampUserDefinition : RemoteUserDefinition
	{
		[JsonProperty("timestamp")]
		public DateTime? Timestamp { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.metadata.remote.RemoteTopNAttribute")]
	public class RemoteTopNAttribute : RemoteDerivedAttribute
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("topN")]
		public int? TopN { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.report.model.RemoteTopTransformationInfo")]
	public class RemoteTopTransformationInfo
	{
		[JsonProperty("state")]
		public String State { get; set; }
		[JsonProperty("topJobName")]
		public String TopJobName { get; set; }
		[JsonProperty("topJobId")]
		public String TopJobId { get; set; }
		[JsonProperty("parentJobId")]
		public String ParentJobId { get; set; }
		[JsonProperty("partitionAttribute")]
		public String PartitionAttribute { get; set; }
		[JsonProperty("executorUserName")]
		public String ExecutorUserName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteTotalPivotOperation")]
	public class RemoteTotalPivotOperation : RemotePivotOperation
	{
	}

	[RemoteName("com.idc_cema.ferda.pivot.remote.domain.operation.RemoteTotalPivotOperationDef")]
	public class RemoteTotalPivotOperationDef : RemotePivotOperationDef
	{
	}

	[RemoteName("com.idc_cema.ferda.welcomescreen.remote.RemoteTrackerFolder")]
	public class RemoteTrackerFolder : RemoteFolder
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransAttribute")]
	public abstract class RemoteTransAttribute
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("targetAttribute")]
		public String TargetAttribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransAttributeConstant")]
	public class RemoteTransAttributeConstant : RemoteTransAttribute
	{
		[JsonProperty("constantValue")]
		public String ConstantValue { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransAttributeSimple")]
	public class RemoteTransAttributeSimple : RemoteTransAttribute
	{
		[JsonProperty("sourceAttribute")]
		public String SourceAttribute { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransConfiguration")]
	public class RemoteTransConfiguration
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("type")]
		public String Type { get; set; }
		[JsonProperty("attributes")]
		public HashSet<RemoteTransAttribute> Attributes { get; set; }
		[JsonProperty("comment")]
		public String Comment { get; set; }
		[JsonProperty("filter")]
		public RemoteCriteriaFilter Filter { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("procedures")]
		public List<RemoteTransStoredProcedure> Procedures { get; set; }
		[JsonProperty("periodType")]
		public String PeriodType { get; set; }
		[JsonProperty("targetTechnology")]
		public String TargetTechnology { get; set; }
		[JsonProperty("conversionMethod")]
		public String ConversionMethod { get; set; }
		[JsonProperty("comparisonCheckAttributes")]
		public HashSet<String> ComparisonCheckAttributes { get; set; }
		[JsonProperty("comparisonCheckFigures")]
		public HashSet<String> ComparisonCheckFigures { get; set; }
		[JsonProperty("dataModelMetadata")]
		public long? DataModelMetadata { get; set; }
		[JsonProperty("allowedFilteringAttributes")]
		public HashSet<RemoteAllowedFilterAttribute> AllowedFilteringAttributes { get; set; }
		[JsonProperty("crossSplitType")]
		public String CrossSplitType { get; set; }
		[JsonProperty("figures")]
		public HashSet<RemoteTransFigure> Figures { get; set; }
		[JsonProperty("sourceTechnology")]
		public String SourceTechnology { get; set; }
		[JsonProperty("sourceSnapshot")]
		public String SourceSnapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransExecutionHistory")]
	public class RemoteTransExecutionHistory
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("filter")]
		public String Filter { get; set; }
		[JsonProperty("configuration")]
		public long? Configuration { get; set; }
		[JsonProperty("user")]
		public String User { get; set; }
		[JsonProperty("executionDate")]
		public DateTime? ExecutionDate { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransFigure")]
	public abstract class RemoteTransFigure
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("targetFigure")]
		public String TargetFigure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransFigureConstant")]
	public class RemoteTransFigureConstant : RemoteTransFigure
	{
		[JsonProperty("constantValue")]
		public Double ConstantValue { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransFigureSimple")]
	public class RemoteTransFigureSimple : RemoteTransFigure
	{
		[JsonProperty("sourceFigure")]
		public String SourceFigure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteTransformation")]
	public class RemoteTransformation
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("sourceTable")]
		public String SourceTable { get; set; }
		[JsonProperty("reportLevel")]
		public String ReportLevel { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.RemoteTransformationFileResponse")]
	public class RemoteTransformationFileResponse : RemoteFileResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransformationChain")]
	public abstract class RemoteTransformationChain
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("initState")]
		public RemoteTransformationState InitState { get; set; }
		[JsonProperty("transformations")]
		public List<RemoteTransformation> Transformations { get; set; }
		[JsonProperty("attributeFilterItems")]
		public HashSet<RemoteAttributeFilterItem> AttributeFilterItems { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransformationChainInner")]
	public class RemoteTransformationChainInner : RemoteTransformationChain
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransformationChainRoot")]
	public class RemoteTransformationChainRoot : RemoteTransformationChain
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteTransformationRenameMapping")]
	public class RemoteTransformationRenameMapping : RemoteTransformation
	{
		[JsonProperty("newColumnName")]
		public String NewColumnName { get; set; }
		[JsonProperty("currentColumnName")]
		public String CurrentColumnName { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransformationState")]
	public class RemoteTransformationState
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.transformer.RemoteTransformer")]
	public abstract class RemoteTransformer
	{
	}

	[RemoteName("com.idc_cema.ferda.crud.remote.transformer.RemoteTransformerObject")]
	public abstract class RemoteTransformerObject
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.domain.format.RemoteTransposedDeliveryColumn")]
	public class RemoteTransposedDeliveryColumn : RemoteDeliveryColumn
	{
		[JsonProperty("attribute")]
		public String Attribute { get; set; }
		[JsonProperty("figure")]
		public String Figure { get; set; }
		[JsonProperty("denominator")]
		public String Denominator { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.RemoteTransStoredProcedure")]
	public class RemoteTransStoredProcedure
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("step")]
		public String Step { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.api.procedure.RemoteTransStoredProcedureRequest")]
	public abstract class RemoteTransStoredProcedureRequest : RemoteRequest
	{
		[JsonProperty("procedure")]
		public long? Procedure { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.db.RemoteTransTable")]
	public class RemoteTransTable : RemoteTable
	{
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.generator.RemoteTriggerReloadRequest")]
	public class RemoteTriggerReloadRequest : RemoteRequest
	{
		[JsonProperty("technologyId")]
		public String TechnologyId { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteUndeployDailySnapshot")]
	public class RemoteUndeployDailySnapshot : RemoteRequest
	{
		[JsonProperty("deployedSnapshotCount")]
		public int DeployedSnapshotCount { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.snapshots.remote.RemoteUndeploySnapshotData")]
	public class RemoteUndeploySnapshotData : RemoteRequest
	{
		[JsonProperty("snapshot")]
		public String Snapshot { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.schema.remote.RemoteUndeployTechnologyRequest")]
	public class RemoteUndeployTechnologyRequest : RemoteRequest
	{
		[JsonProperty("technology")]
		public String Technology { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteUnionAllMergeTransformation")]
	public class RemoteUnionAllMergeTransformation : RemoteTransformation
	{
		[JsonProperty("transformationChainList")]
		public List<RemoteTransformationChain> TransformationChainList { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.shipments.remote.RemoteUnionQuery")]
	public class RemoteUnionQuery : RemoteRequest
	{
		[JsonProperty("queries")]
		public RemoteList Queries { get; set; }
		[JsonProperty("figureMapping")]
		public List<RemoteQMapping> FigureMapping { get; set; }
		[JsonProperty("attributeMapping")]
		public List<RemoteQMapping> AttributeMapping { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.configuration.RemoteUpdateClientDeliveryConfigurationRequest")]
	public class RemoteUpdateClientDeliveryConfigurationRequest : RemoteRequest
	{
		[JsonProperty("configuration")]
		public RemoteClientDeliveryConfiguration Configuration { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.profile.RemoteUpdateClientDeliveryProfileRequest")]
	public class RemoteUpdateClientDeliveryProfileRequest : RemoteSaveClientDeliveryProfileRequest
	{
	}

	[RemoteName("com.idc_cema.ferda.clientdelivery.remote.report.RemoteUpdateClientDeliveryReportRequest")]
	public class RemoteUpdateClientDeliveryReportRequest : RemoteRequest
	{
		[JsonProperty("report")]
		public RemoteClientDeliveryReport Report { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteUpdateFiguresToZeroTrans")]
	public class RemoteUpdateFiguresToZeroTrans : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteUpdateImportManagerTransformation")]
	public class RemoteUpdateImportManagerTransformation : RemoteTransformation
	{
		[JsonProperty("filterGroup")]
		public RemoteQueryFilterGroup FilterGroup { get; set; }
		[JsonProperty("transformationChainList")]
		public List<RemoteTransformationChain> TransformationChainList { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteUpdateNavigatorNode")]
	public class RemoteUpdateNavigatorNode : RemoteManipulateNavigatorNode
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteUpdateNavigatorNodeResponse")]
	public class RemoteUpdateNavigatorNodeResponse : RemoteManipulateNavigatorNodeResponse
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteUpdateShipmentIdTransformation")]
	public class RemoteUpdateShipmentIdTransformation : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.transformation.remote.domain.transformations.RemoteUpdateShipmentTransformation")]
	public class RemoteUpdateShipmentTransformation : RemoteTransformation
	{
	}

	[RemoteName("com.idc_cema.ferda.file.remote.api.RemoteUploadFileRequest")]
	public class RemoteUploadFileRequest : RemoteRequest
	{
		[JsonProperty("data")]
		public byte[] Data { get; set; }
		[JsonProperty("ferdaFile")]
		public RemoteFerdaFile FerdaFile { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.file.remote.api.RemoteUploadFileResponse")]
	public class RemoteUploadFileResponse : RemoteResponse
	{
		[JsonProperty("file")]
		public long? File { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.collector.remote.RemoteUsageDataCollector")]
	public class RemoteUsageDataCollector
	{
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("pcId")]
		public String PcId { get; set; }
		[JsonProperty("ipAddress")]
		public String IpAddress { get; set; }
		[JsonProperty("memory")]
		public int? Memory { get; set; }
		[JsonProperty("cpuCount")]
		public int? CpuCount { get; set; }
		[JsonProperty("collectStart")]
		public DateTime? CollectStart { get; set; }
		[JsonProperty("collectEnd")]
		public DateTime? CollectEnd { get; set; }
		[JsonProperty("recordCount")]
		public int RecordCount { get; set; }
		[JsonProperty("sessionId")]
		public String SessionId { get; set; }
		[JsonProperty("technology")]
		public String Technology { get; set; }
		[JsonProperty("operatingSystem")]
		public String OperatingSystem { get; set; }
		[JsonProperty("featureDetailOne")]
		public String FeatureDetailOne { get; set; }
		[JsonProperty("featureDetailTwo")]
		public String FeatureDetailTwo { get; set; }
		[JsonProperty("featureDetailThree")]
		public String FeatureDetailThree { get; set; }
		[JsonProperty("user")]
		public String User { get; set; }
		[JsonProperty("timescale")]
		public long? Timescale { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RemoteUser")]
	public class RemoteUser
	{
		[JsonProperty("firstName")]
		public String FirstName { get; set; }
		[JsonProperty("lastName")]
		public String LastName { get; set; }
		[JsonProperty("office")]
		public String Office { get; set; }
		[JsonProperty("analystRoles")]
		public HashSet<RemoteAnalystRole> AnalystRoles { get; set; }
		[JsonProperty("mail")]
		public String Mail { get; set; }
		[JsonProperty("mobile")]
		public String Mobile { get; set; }
		[JsonProperty("username")]
		public String Username { get; set; }
		[JsonProperty("phone")]
		public String Phone { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteUserDefinition")]
	public abstract class RemoteUserDefinition
	{
		[JsonProperty("name")]
		public String Name { get; set; }
		[JsonProperty("id")]
		public long? Id { get; set; }
		[JsonProperty("definition")]
		public String Definition { get; set; }
		[JsonProperty("description")]
		public String Description { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteUserDefinitionNavigatorNode")]
	public abstract class RemoteUserDefinitionNavigatorNode : RemoteNavigatorNode
	{
	}

	[RemoteName("com.idc_cema.ferda.validator.remote.RemoteValidateRequest")]
	public class RemoteValidateRequest : RemoteRequest
	{
		[JsonProperty("payload")]
		public Object Payload { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.validator.remote.RemoteValidateResponse")]
	public class RemoteValidateResponse : RemoteResponse
	{
		[JsonProperty("errors")]
		public RemoteMap Errors { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.qc.remote.RemoteVersionComparisonCheck")]
	public class RemoteVersionComparisonCheck : RemoteComparisonCheck
	{
		[JsonProperty("primaryDataVersion")]
		public String PrimaryDataVersion { get; set; }
		[JsonProperty("secondaryDataVersion")]
		public String SecondaryDataVersion { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteWebPivotBookmark")]
	public class RemoteWebPivotBookmark : RemoteTimestampUserDefinition
	{
	}

	[RemoteName("com.idc_cema.ferda.navigator.remote.RemoteWebPivotBookmarkNavigatorNode")]
	public class RemoteWebPivotBookmarkNavigatorNode : RemoteUserDefinitionNavigatorNode
	{
		[JsonProperty("bookmark")]
		public RemoteWebPivotBookmark Bookmark { get; set; }
	}

	[RemoteName("com.idc_cema.ferda.security.remote.RoleGroupType")]
	public enum RoleGroupType
	{
		GLOBAL,
		TECHNOLOGY,
		SHIPMENT
	}

	[RemoteName("com.idc_cema.ferda.job.integration.IScheduledJobRouter")]
	public interface IScheduledJobRouter
	{
	}

	[RemoteName("com.idc_cema.ferda.job.integration.ScheduledJobRouterType")]
	public enum ScheduledJobRouterType
	{
		DEFAULT,
		LOAD_DATA,
		FLUSH_DATA,
		CLIENT_DELIVERY,
		CRON_JOB,
		CRON_JOB_DAILY_BACKUP,
		CRON_JOB_CONSISTENCY,
		CRON_JOB_DASHBOARD,
		CRON_JOB_ATTRIBUTES_VALUES,
		TRANS,
		TRANS_PARTITION,
		TRANS_LOAD_DATA,
		TRANS_CONVERT_NODES,
		TRANS_DEFAULT_PARALLEL,
		TRANS_CROSS_SPLIT,
		PRICEBAND_CALCULATION,
		DATA_EXPORT,
		CROSS_SPLIT
	}

}
