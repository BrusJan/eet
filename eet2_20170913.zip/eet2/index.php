<?php 
require_once 'core/init.php';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>
<p>This is secure area.</p>
<p><a href="<?php echo dashboard; ?>">Dashboard</a></p>
<a href="<?php echo logout; ?>">Logout</a>
</div>
</body>
</html>
