<?php 
	class Redirect
	{
		/**
		*  Public method to help in redirecting to pages
		*/
		public static function to($location = null)
		{
			echo 'redirect';
			if ($location) 
			{
				echo $location;
				header('location: ' . $baseUrl . $location);
				exit();
			}
		}
	}
	
?>